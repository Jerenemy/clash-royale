import unittest
import pygame
import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from game.settings import *
from game.core.managers import BattleManager
from game.entities.sprites import Unit

class MockEngine:
    def __init__(self):
        self.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    def get_mouse_pos(self):
        return (0, 0)

class TestMusketeerTowerLock(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MockEngine()
        self.manager = BattleManager(self.engine)

    def test_lock_on_tower_ignore_unit(self):
        # Spawn Musketeer (Player) at Y=400 (Middle-ish)
        # Enemy Princess Tower is at Y ~ 160. Distance ~ 240.
        # Musketeer Range ~ 250.
        # So it should lock onto the tower.
        
        musketeer = Unit(self.manager, 150, 400, "musketeer", "player")
        
        # Ensure no other units
        for u in self.manager.units:
            if u != musketeer:
                u.kill()
                
        # Update to find target
        musketeer.update(0.1)
        
        # Check target is tower
        target = musketeer.target
        self.assertIsNotNone(target, "Musketeer should have a target")
        self.assertEqual(getattr(target, 'type', ''), 'princess', "Musketeer should target princess tower")
        
        print(f"Locked onto: {target} at {target.pos}")
        
        # Now spawn an enemy unit CLOSER than the tower.
        # Tower dist ~ 240.
        # Spawn unit at Y=350 (Dist 50).
        enemy_unit = Unit(self.manager, 150, 350, "knight", "enemy")
        
        # Update Musketeer
        musketeer.update(0.1)
        
        # Should STILL target the tower because it's locked!
        self.assertEqual(musketeer.target, target, 
                         f"Musketeer switched target to {musketeer.target} (Unit) but should have stayed on Tower!")
        
        if musketeer.target == enemy_unit:
            self.fail("Musketeer switched to closer unit without being nudged!")
            
        # Now NUDGE the Musketeer
        musketeer.nudged = True
        musketeer.update(0.1)
        
        # NOW it should switch to the closer unit
        self.assertEqual(musketeer.target, enemy_unit, "Musketeer should switch to closer unit after nudge")

if __name__ == '__main__':
    unittest.main()
