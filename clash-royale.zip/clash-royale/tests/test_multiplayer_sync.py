
import unittest
import time
import queue
import threading
from unittest.mock import MagicMock, patch
import sys
import os

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Mock pygame
sys.modules["pygame"] = MagicMock()
import pygame
pygame.Rect = MagicMock()
pygame.math = MagicMock()

class MockGroup(set):
    def add(self, *sprites):
        for sprite in sprites:
            super().add(sprite)
    def remove(self, *sprites):
        for sprite in sprites:
            if sprite in self:
                super().remove(sprite)
    def draw(self, surface):
        pass
    def update(self, *args):
        pass
    def empty(self):
        self.clear()

pygame.sprite.Group = MockGroup

# Mock settings
sys.modules["settings"] = MagicMock()
from settings import *
sys.modules["settings"].MAX_ELIXIR = 10
sys.modules["settings"].ELIXIR_REGEN_RATE = 2.8
sys.modules["settings"].SCREEN_WIDTH = 540
sys.modules["settings"].SCREEN_HEIGHT = 960
sys.modules["settings"].UNIT_STATS = {
    "knight": {"cost": 3, "health": 1000, "count": 1},
    "archer": {"cost": 3, "health": 300, "count": 1}
}
sys.modules["settings"].SPELL_STATS = {}
sys.modules["settings"].TOWER_STATS = {
    "princess": {"health": 2500, "damage": 100, "range": 250, "attack_speed": 0.8, "size": 40},
    "king": {"health": 4000, "damage": 120, "range": 250, "attack_speed": 1.0, "size": 60}
}

# Mock sprites
mock_sprites = MagicMock()
sys.modules["sprites"] = mock_sprites

# Define Mock Classes for Sprites
class MockEntity:
    def __init__(self, game, x, y, team, network_id=None):
        self.game = game
        self.team = team
        self.network_id = network_id
        self.health = 100
        self.max_health = 100
        self.alive_val = True
        
    def alive(self):
        return self.alive_val
        
    def kill(self):
        self.alive_val = False
        if self in self.game.units:
            self.game.units.remove(self)
            
    def take_damage(self, amount):
        self.health -= amount

class MockUnit(MockEntity):
    def __init__(self, game, x, y, type, team, network_id=None):
        super().__init__(game, x, y, team, network_id)
        self.game.units.add(self)

class MockTower(MockEntity):
    def __init__(self, game, x, y, type, team, network_id=None):
        super().__init__(game, x, y, team, network_id)
        self.game.towers.add(self)

# Assign mocks to module
mock_sprites.Unit = MockUnit
mock_sprites.Tower = MockTower
mock_sprites.FlyingUnit = MockUnit # Reuse MockUnit
mock_sprites.Spell = MagicMock()

# Now import game modules
from network_battle_manager import NetworkBattleManager
from network_protocol import ActionType, MessageType

class MockNetworkClient:
    def __init__(self, latency=0.0):
        self.latency = latency
        self.out_queue = queue.Queue()
        self.in_queue = queue.Queue()
        self.on_game_action = None
        self.on_disconnect = None
        self.on_error = None
        self.player_id = "player1"

    def send_action(self, action_type, action_data):
        msg = {
            "type": MessageType.GAME_ACTION,
            "data": {
                "player_id": self.player_id,
                "action_type": action_type,
                "action_data": action_data
            }
        }
        self.out_queue.put((time.time() + self.latency, msg))

    def poll_messages(self):
        while not self.in_queue.empty():
            timestamp, msg = self.in_queue.queue[0]
            # Ignore timestamp for test speed
            self.in_queue.get()
            if msg["type"] == MessageType.GAME_ACTION:
                data = msg["data"]
                if self.on_game_action:
                    self.on_game_action(data["action_type"], data["action_data"])

class TestMultiplayerSync(unittest.TestCase):
    def setUp(self):
        self.screen = MagicMock()
        
        # Client 1
        self.client1 = MockNetworkClient(latency=0.0)
        self.client1.player_id = "p1"
        deck = ["knight", "archer", "knight", "archer", "knight", "archer", "knight", "archer"]
        self.manager1 = NetworkBattleManager(self.screen, self.client1, "player", "p2", deck)
        
        # Client 2
        self.client2 = MockNetworkClient(latency=0.0)
        self.client2.player_id = "p2"
        self.manager2 = NetworkBattleManager(self.screen, self.client2, "enemy", "p1", deck)
        
        # Link clients
        def transfer_messages():
            while not self.client1.out_queue.empty():
                t, msg = self.client1.out_queue.get()
                self.client2.in_queue.put((t, msg))
            
            while not self.client2.out_queue.empty():
                t, msg = self.client2.out_queue.get()
                self.client1.in_queue.put((t, msg))
                
        self.transfer_messages = transfer_messages

    def test_damage_sync(self):
        """Test that damage is consistent across clients"""
        # Player 1 plays a Knight
        pos = (100, 100)
        self.manager1.dragging_card_idx = 0
        self.manager1.try_play_card(pos) 
        
        # Spy on spawn_card
        self.manager2.spawn_card = MagicMock(wraps=self.manager2.spawn_card)
        
        # Process messages
        self.transfer_messages()
        self.manager2.update(0.016)
        
        # Find the units
        unit1 = None
        for u in self.manager1.units:
            if u.team == "player":
                unit1 = u
                break
                
        unit2 = None
        for u in self.manager2.units:
            if u.team == "enemy": # It's enemy to player 2
                unit2 = u
                break
                
        self.assertIsNotNone(unit1, "Unit1 not found")
        self.assertIsNotNone(unit2, "Unit2 not found")
        self.assertEqual(unit1.network_id, unit2.network_id)
        
        # Deal damage to unit1 (Authoritative side)
        unit1.take_damage(50)
        self.assertEqual(unit1.health, unit1.max_health - 50)
        
        # Unit 2 should still be full health before sync
        self.assertEqual(unit2.health, unit2.max_health)
        
        # Trigger sync
        self.manager1.send_tower_health()
        self.transfer_messages()
        self.manager2.update(0.016)
        
        # Unit 2 should now be updated
        self.assertEqual(unit2.health, unit1.health)

if __name__ == "__main__":
    unittest.main()
