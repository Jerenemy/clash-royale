import unittest
import pygame
import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from game.settings import *
from game.core.managers import BattleManager
from game.entities.sprites import Unit

class MockEngine:
    def __init__(self):
        self.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    def get_mouse_pos(self):
        return (0, 0)

class TestBridgeStuck(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MockEngine()
        self.manager = BattleManager(self.engine)
        self.arena = self.manager.arena

    def test_bridge_crossing(self):
        # Spawn a unit at the bottom bridge entrance (Left Bridge)
        # Left Bridge X is around 96 + 2*26 + 13 = 161
        bridge_rect = self.arena.left_bridge_rect
        start_x = bridge_rect.centerx
        start_y = bridge_rect.bottom + 10
        
        unit = Unit(self.manager, start_x, start_y, "giant", "player")
        
        # Target: Enemy King Tower (Top Center) - Forces crossing
        unit.target = self.manager.king_tower_e
        
        # Simulate movement
        dt = 0.1
        # Speed is approx 40 px/sec. Bridge height is ~60px.
        # Should cross in 1.5 seconds.
        # Let's give it 5 seconds (50 steps)
        steps = 100 
        
        crossed = False
        
        print(f"Start Pos: {unit.pos}")
        print(f"Bridge Rect: {bridge_rect}")
        print(f"River Rect: {self.arena.river_rect}")
        
        last_pos = unit.pos.copy()
        stuck_frames = 0
        
        for i in range(steps):
            unit.update(dt)
            
            # Check if stuck (not moving)
            if unit.pos.distance_to(last_pos) < 0.1:
                stuck_frames += 1
            else:
                stuck_frames = 0
            last_pos = unit.pos.copy()
            
            if stuck_frames > 10:
                print(f"Stuck at {unit.pos} for 10 frames!")
            
            # Check if passed the river (Top of river is Y ~ 330)
            if unit.pos.y < self.arena.river_rect.top - 10:
                crossed = True
                break
                
        if not crossed:
            print(f"Final Pos: {unit.pos}")
            self.fail(f"Unit failed to cross the bridge. Stuck at {unit.pos}")

if __name__ == '__main__':
    unittest.main()
