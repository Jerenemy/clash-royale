import unittest
import pygame
from game.core.arena import Arena
from game.settings import *

class MockManager:
    def __init__(self):
        self.screen = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.playable_height = 620
        self.left_tower_e = None
        self.right_tower_e = None

class TestVisuals(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.manager = MockManager()
        self.arena = Arena(self.manager)

    def test_grid_lines_not_present(self):
        """
        Inspect the arena background to ensure no black grid lines are present.
        We'll sample pixels at the boundaries of tiles.
        """
        bg = self.arena.background
        
        # Check a vertical grid line
        # x = margin + tile_size
        # y = tile_size // 2 (middle of first row)
        x = GRID_MARGIN_X + TILE_SIZE
        y = TILE_SIZE // 2
        
        pixel = bg.get_at((x, y))
        print(f"Pixel at vertical grid line ({x}, {y}): {pixel}")
        
        # It should NOT be black or dark grey.
        # It should be either GRASS_LIGHT or GRASS_DARK.
        # GRASS_LIGHT = (100, 200, 100)
        # GRASS_DARK = (80, 180, 80)
        
        is_black = pixel[0] < 20 and pixel[1] < 20 and pixel[2] < 20
        self.assertFalse(is_black, f"Found black pixel at grid line: {pixel}")
        
        # Check a horizontal grid line
        # x = margin + tile_size // 2
        # y = tile_size
        x = GRID_MARGIN_X + TILE_SIZE // 2
        y = TILE_SIZE
        
        pixel = bg.get_at((x, y))
        print(f"Pixel at horizontal grid line ({x}, {y}): {pixel}")
        
        is_black = pixel[0] < 20 and pixel[1] < 20 and pixel[2] < 20
        self.assertFalse(is_black, f"Found black pixel at grid line: {pixel}")

    def test_river_no_grid(self):
        """Check that the river does not have grid lines."""
        bg = self.arena.background
        
        # River is at river_rect.
        # Let's find a vertical grid line passing through the river.
        river_y = self.arena.river_rect.centery
        x = GRID_MARGIN_X + TILE_SIZE * 5 # Arbitrary column
        
        pixel = bg.get_at((x, int(river_y)))
        print(f"Pixel at river grid line ({x}, {river_y}): {pixel}")
        
        # Should be RIVER_BLUE (50, 150, 255)
        # Definitely not black.
        is_black = pixel[0] < 20 and pixel[1] < 20 and pixel[2] < 20
        self.assertFalse(is_black, f"Found black pixel in river at grid line: {pixel}")

if __name__ == "__main__":
    unittest.main()
