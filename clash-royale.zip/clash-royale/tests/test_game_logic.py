import unittest
import pygame
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from models import Player
from sprites import Unit
from managers import BattleManager

# Mock classes to avoid full Pygame init
class MockGame:
    def __init__(self):
        self.all_sprites = pygame.sprite.Group()
        self.units = pygame.sprite.Group()
        self.towers = pygame.sprite.Group()
        self.projectiles = pygame.sprite.Group()
        self.king_tower_e = MockTower()
        self.king_tower_p = MockTower()

class MockTower:
    def __init__(self):
        self.rect = pygame.Rect(0, 0, 10, 10)
        self.health = 1000
        self.active = True
    def alive(self): return True

class TestGameLogic(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.deck = ["c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8"]
        
    def test_deck_cycle(self):
        player = Player("player", self.deck)
        
        # Initial State
        self.assertEqual(len(player.hand), 4)
        self.assertEqual(len(player.deck), 3) # 8 total - 4 hand - 1 next = 3 in deck
        self.assertIsNotNone(player.next_card)
        
        initial_hand = player.hand.copy()
        next_card = player.next_card
        
        # Play a card
        played_card = player.play_card(0)
        
        # Verify Cycle
        self.assertNotIn(played_card, player.hand) # Should be gone from hand
        self.assertEqual(player.hand[0], next_card) # Next card should take its place
        self.assertEqual(player.deck[-1], played_card) # Played card should be at bottom of deck
        
    def test_unit_deployment(self):
        game = MockGame()
        # Mock UNIT_STATS
        import sprites
        sprites.UNIT_STATS = {"knight": {"health": 100, "damage": 10, "speed": 1, "range": 1, "attack_speed": 1, "cost": 3, "color": (0,0,0)}}
        
        unit = Unit(game, 0, 0, "knight", "player")
        
        self.assertEqual(unit.state, "deploying")
        self.assertEqual(unit.deploy_timer, 1.0)
        
        # Update for 0.5s
        unit.update(0.5)
        self.assertEqual(unit.state, "deploying")
        
        # Update for another 0.6s (total 1.1s)
        unit.update(0.6)
        self.assertEqual(unit.state, "active")
        
    def test_sudden_death_trigger(self):
        # We need to mock BattleManager significantly or use a real one with mocked screen
        # Let's try to use real BattleManager but mock screen
        screen = pygame.Surface((100, 100))
        bm = BattleManager(screen)
        
        # Set timer to near 0
        bm.battle_timer = 0.1
        bm.sudden_death = False
        
        # Update to cross 0
        bm.update(0.2)
        
        # Should be in Sudden Death (scores tied at start)
        self.assertTrue(bm.sudden_death)
        self.assertEqual(bm.battle_timer, 120.0) # Reset to 2 mins
        
    def test_sudden_death_win(self):
        screen = pygame.Surface((100, 100))
        bm = BattleManager(screen)
        
        # Force Sudden Death
        bm.sudden_death = True
        bm.sd_start_towers_p = 3
        bm.sd_start_towers_e = 3
        
        # Simulate tower loss
        # We need to remove a tower from the group
        tower_to_kill = bm.left_tower_p
        tower_to_kill.kill()
        
        # Update
        bm.update(0.1)
        
        # Should be Game Over, Enemy Wins
        self.assertTrue(bm.game_over)
        self.assertEqual(bm.winner, "Enemy")

if __name__ == '__main__':
    unittest.main()
