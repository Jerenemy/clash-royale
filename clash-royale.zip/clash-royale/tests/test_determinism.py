import unittest
import pygame
from unittest.mock import MagicMock
from game.core.managers import BattleManager
from game.core.game import Game
from game.entities.sprites import Unit
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT

class TestDeterminism(unittest.TestCase):
    def setUp(self):
        pygame.init()
        pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        
    def test_variable_dt_desync(self):
        """
        Demonstrate that variable dt causes desync.
        We run two identical simulations with different dt patterns.
        """
        mock_engine = MagicMock()
        mock_engine.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        
        # Sim 1: Fixed 16ms steps
        game1 = BattleManager(mock_engine)
        game1.reset_game()
        unit1 = Unit(game1, 100, 100, "knight", "player")
        
        # Sim 2: Variable steps (e.g. 32ms then 0ms, or just larger steps)
        game2 = BattleManager(mock_engine)
        game2.reset_game()
        unit2 = Unit(game2, 100, 100, "knight", "player")
        
        # Run for 1 second total
        # Sim 1: 60 steps of 0.0166s
        for _ in range(60):
            game1.update(0.0166666)
            
        # Sim 2: 30 steps of 0.0333s (lower framerate)
        for _ in range(30):
            game2.update(0.0333333)
            
        # Positions should be ROUGHLY similar but likely not identical due to float math / collision logic
        # If they are identical, then the game is already time-independent (unlikely)
        
        print(f"Pos 1: {unit1.pos}")
        print(f"Pos 2: {unit2.pos}")
        
        # We expect them to be different if the logic is sensitive to dt
        # If we implement fixed timestep, we would expect them to be identical (if we force the engine to step)
        
        # For this test, we just want to see if they diverge
        diff = unit1.pos.distance_to(unit2.pos)
        print(f"Difference: {diff}")
        
        # If diff > 0.1, we have a determinism problem
        if diff > 0.1:
            print("CONFIRMED: Variable dt causes desync")
        else:
            print("Surprising: Simulation seems robust to dt")

if __name__ == "__main__":
    unittest.main()
