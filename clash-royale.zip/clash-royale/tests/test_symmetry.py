import unittest
import pygame
import math
from unittest.mock import MagicMock
from game.core.managers import BattleManager
from game.entities.sprites import Unit
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT, HUD_HEIGHT

class TestSymmetry(unittest.TestCase):
    def setUp(self):
        pygame.init()
        # Mock engine
        self.engine = MagicMock()
        self.engine.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        
        # Create two battle managers: Host and Client
        # Host sees game as "player" (bottom) vs "enemy" (top)
        # Client sees game as "player" (bottom) vs "enemy" (top)
        # BUT, Host's "player" is Client's "enemy".
        
        self.host_game = BattleManager(self.engine)
        self.client_game = BattleManager(self.engine)
        
        # Playable height logic
        self.playable_height = SCREEN_HEIGHT - HUD_HEIGHT
        
    def tearDown(self):
        pygame.quit()
        
    def get_mirrored_pos(self, x, y):
        """Calculate expected position on the other client's screen."""
        from game.core.symmetry import SymmetryUtils
        return SymmetryUtils.flip_pos((x, y))
        
    def test_static_mirroring(self):
        """Test that a unit spawned on Host appears at mirrored pos on Client."""
        # Spawn unit on Host at (100, 200) belonging to Host ("player")
        # On Client, this unit belongs to "enemy".
        
        # Host spawns unit
        h_unit = Unit(self.host_game, 100, 200, "knight", "player")
        
        # Client receives spawn command (simulated)
        # Client needs to flip coordinates
        spawn_x, spawn_y = self.get_mirrored_pos(100, 200)
        c_unit = Unit(self.client_game, spawn_x, spawn_y, "knight", "enemy")
        
        # Check positions
        self.assertEqual(h_unit.pos.x, 100)
        self.assertEqual(h_unit.pos.y, 200)
        self.assertEqual(c_unit.pos.x, spawn_x)
        self.assertEqual(c_unit.pos.y, spawn_y)
        
        # Verify they are mirrored
        expected_x, expected_y = self.get_mirrored_pos(h_unit.pos.x, h_unit.pos.y)
        self.assertAlmostEqual(c_unit.pos.x, expected_x, places=2)
        self.assertAlmostEqual(c_unit.pos.y, expected_y, places=2)

    def test_dynamic_symmetry(self):
        """Test that units move symmetrically."""
        # Host unit at bottom-left, moving up-right
        h_unit = Unit(self.host_game, 100, 600, "knight", "player")
        
        # Client unit (same entity) at top-right, moving down-left
        start_x, start_y = self.get_mirrored_pos(100, 600)
        c_unit = Unit(self.client_game, start_x, start_y, "knight", "enemy")
        
        # Force targets to be symmetric
        # Host targets enemy tower at top-right
        h_target = self.host_game.right_tower_e 
        h_unit.target = h_target
        
        # Client targets player tower at bottom-left (which is the mirrored version of Host's enemy tower)
        # Host's right_tower_e is at (WIDTH-80, 150)
        # Mirrored pos: (80, PLAYABLE_HEIGHT - 150) -> This is Client's left_tower_p
        c_target = self.client_game.left_tower_p
        c_unit.target = c_target
        
        # Verify targets are symmetric
        expected_target_x, expected_target_y = self.get_mirrored_pos(h_target.pos.x, h_target.pos.y)
        self.assertAlmostEqual(c_target.pos.x, expected_target_x, places=2)
        self.assertAlmostEqual(c_target.pos.y, expected_target_y, places=2)
        
        # Simulate 100 frames
        dt = 0.016
        for _ in range(100):
            h_unit.update(dt)
            c_unit.update(dt)
            
            # Verify symmetry at every step
            exp_x, exp_y = self.get_mirrored_pos(h_unit.pos.x, h_unit.pos.y)
            self.assertAlmostEqual(c_unit.pos.x, exp_x, places=4, msg=f"X mismatch at frame {_}")
            self.assertAlmostEqual(c_unit.pos.y, exp_y, places=4, msg=f"Y mismatch at frame {_}")

if __name__ == '__main__':
    unittest.main()
