import pytest
import pygame
import math
from game.core.game import Game
from game.entities.sprites import Unit
from game.settings import *

class MockTower(pygame.sprite.Sprite):
    def __init__(self, x, y, team, size=60):
        super().__init__()
        self.pos = pygame.math.Vector2(x, y)
        self.rect = pygame.Rect(x, y, size, size)
        self.rect.center = (x, y)
        self.team = team
        self.size = size
        self.alive = lambda: True
        
    def take_damage(self, amount):
        pass

class MockGame:
    def __init__(self):
        self.units = pygame.sprite.Group()
        self.towers = pygame.sprite.Group()
        self.all_sprites = pygame.sprite.Group()
        self.projectiles = pygame.sprite.Group()
        self.playable_height = 620
        
        # Mock towers
        self.king_tower_p = MockTower(240, 700, 'player')
        self.king_tower_e = MockTower(240, 100, 'enemy')
        self.towers.add(self.king_tower_p)
        self.towers.add(self.king_tower_e)

def test_symmetric_collision():
    pygame.init()
    game = MockGame()
    
    # Spawn symmetric pairs of units colliding
    # Left pair
    l1 = Unit(game, 100, 300, "knight", "player", network_id="l1")
    l2 = Unit(game, 100, 320, "knight", "enemy", network_id="l2")
    
    # Right pair (mirrored)
    # Mirror X: 480 - 100 = 380
    # Mirror Y: 620 - 300 = 320 (relative to playable area?)
    # Let's just mirror X for simplicity to test left/right symmetry
    r1 = Unit(game, 380, 300, "knight", "player", network_id="r1")
    r2 = Unit(game, 380, 320, "knight", "enemy", network_id="r2")
    
    # Update
    dt = 0.05
    for _ in range(50):
        # Update all
        l1.update(dt)
        l2.update(dt)
        r1.update(dt)
        r2.update(dt)
        
        # Check symmetry
        # l1.x should be SCREEN_WIDTH - r1.x
        # l1.y should be r1.y (since we only mirrored X)
        
        assert abs(l1.pos.x - (SCREEN_WIDTH - r1.pos.x)) < 0.1, f"X Asymmetry: {l1.pos.x} vs {r1.pos.x}"
        assert abs(l1.pos.y - r1.pos.y) < 0.1, f"Y Asymmetry: {l1.pos.y} vs {r1.pos.y}"
        
        assert abs(l2.pos.x - (SCREEN_WIDTH - r2.pos.x)) < 0.1, f"X Asymmetry: {l2.pos.x} vs {r2.pos.x}"
        assert abs(l2.pos.y - r2.pos.y) < 0.1, f"Y Asymmetry: {l2.pos.y} vs {r2.pos.y}"

def test_symmetric_crowding():
    pygame.init()
    game = MockGame()
    
    # Spawn a crowd on left
    units_l = []
    for i in range(5):
        u = Unit(game, 100 + i*2, 300 + i*2, "skeleton_army", "player", network_id=f"l_{i}")
        units_l.append(u)
        
    # Spawn mirrored crowd on right
    units_r = []
    for i in range(5):
        u = Unit(game, 380 - i*2, 300 + i*2, "skeleton_army", "player", network_id=f"r_{i}")
        units_r.append(u)
        
    # Update
    dt = 0.05
    for _ in range(50):
        for u in units_l + units_r:
            u.update(dt)
            
        # Check symmetry for each pair
        for i in range(5):
            ul = units_l[i]
            ur = units_r[i]
            
            assert abs(ul.pos.x - (SCREEN_WIDTH - ur.pos.x)) < 0.1
            assert abs(ul.pos.y - ur.pos.y) < 0.1
