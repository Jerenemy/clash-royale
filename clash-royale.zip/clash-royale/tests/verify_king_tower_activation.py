import unittest
import pygame
import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from game.settings import *
from game.core.managers import BattleManager
from game.entities.sprites import Unit

class MockEngine:
    def __init__(self):
        self.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    def get_mouse_pos(self):
        return (0, 0)

class TestKingTowerActivation(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MockEngine()
        self.manager = BattleManager(self.engine)
        
        # Ensure King Towers are initially inactive
        self.assertFalse(self.manager.king_tower_p.active, "Player King Tower should be inactive initially")
        self.assertFalse(self.manager.king_tower_e.active, "Enemy King Tower should be inactive initially")
        
        # Ensure Princess Towers are active
        self.assertTrue(self.manager.left_tower_p.active, "Player Left Tower should be active")

    def test_activation_on_damage(self):
        kt = self.manager.king_tower_p
        
        # Deal damage
        kt.take_damage(10)
        
        self.assertTrue(kt.active, "King Tower should activate after taking damage")
        
    def test_activation_on_princess_tower_death(self):
        kt = self.manager.king_tower_p
        pt = self.manager.left_tower_p
        
        # Kill Princess Tower
        pt.take_damage(pt.health + 10)
        
        # Update manager to check activation
        self.manager.update(0.1)
        
        self.assertTrue(kt.active, "King Tower should activate after Princess Tower is destroyed")
        
    def test_no_attack_when_inactive(self):
        kt = self.manager.king_tower_p
        
        # Spawn enemy unit in range
        enemy = Unit(self.manager, kt.pos.x, kt.pos.y + 100, "knight", "enemy")
        
        # Update manager
        self.manager.update(0.1)
        
        # Should NOT have a target because inactive
        self.assertIsNone(kt.target, "Inactive King Tower should not acquire target")
        
        # Activate it
        kt.active = True
        
        # Update manager
        self.manager.update(0.1)
        
        # Should NOW have a target
        self.assertEqual(kt.target, enemy, "Active King Tower should acquire target")

if __name__ == '__main__':
    unittest.main()
