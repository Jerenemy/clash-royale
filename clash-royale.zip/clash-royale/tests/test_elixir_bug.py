import unittest
import pygame
from unittest.mock import MagicMock
from game.core.managers import BattleManager
from game.core.card import UnitCard
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT, MAX_ELIXIR

class TestElixirBug(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.screen = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.mock_engine = MagicMock()
        self.mock_engine.virtual_surface = self.screen
        self.mock_engine.get_mouse_pos.return_value = (0, 0)
        self.manager = BattleManager(self.mock_engine)
        
        # Mock player hand with a cheap card
        self.card = UnitCard("knight", {"cost": 3, "unit_type": "ground", "health": 100, "damage": 10, "attack_speed": 1.0, "speed": 1.0, "range": 1, "color": (0,0,255)})
        self.manager.player.hand = [self.card] * 4
        self.manager.player.deck = [self.card] * 4
        self.manager.player.next_card = self.card

    def test_play_at_max_elixir(self):
        """Test playing a card when elixir is at maximum."""
        self.manager.player.elixir = MAX_ELIXIR
        self.manager.dragging_card_idx = 0
        
        # Valid spawn pos
        pos = (100, 600)
        
        try:
            self.manager.try_play_card(pos)
        except Exception as e:
            self.fail(f"try_play_card raised exception: {e}")
            
        # Check if card was played
        # If played, elixir should be MAX - 3 = 7
        self.assertEqual(self.manager.player.elixir, MAX_ELIXIR - 3)

    def test_play_sequence(self):
        """Test playing multiple cards in sequence."""
        self.manager.player.elixir = 10
        self.manager.dragging_card_idx = 0
        pos = (100, 600)
        
        # Play 1st card
        self.manager.try_play_card(pos)
        self.assertEqual(self.manager.player.elixir, 7)
        
        # Simulate regen back to 10
        self.manager.player.elixir = 10
        self.manager.dragging_card_idx = 0 # Select new first card
        
        # Play 2nd card
        self.manager.try_play_card(pos)
        self.assertEqual(self.manager.player.elixir, 7)

if __name__ == '__main__':
    unittest.main()
