import pytest
import pygame
import math
from game.core.game import Game
from game.entities.sprites import Unit
from game.settings import *

class MockTower(pygame.sprite.Sprite):
    def __init__(self, x, y, team, size=60):
        super().__init__()
        self.pos = pygame.math.Vector2(x, y)
        self.rect = pygame.Rect(x, y, size, size)
        self.rect.center = (x, y)
        self.team = team
        self.size = size
        self.alive = lambda: True
        
    def take_damage(self, amount):
        pass

class MockGame:
    def __init__(self):
        self.units = pygame.sprite.Group()
        self.towers = pygame.sprite.Group()
        self.all_sprites = pygame.sprite.Group()
        self.projectiles = pygame.sprite.Group()
        self.playable_height = 620
        
        # Mock towers for targeting
        self.king_tower_p = MockTower(100, 700, 'player')
        self.king_tower_e = MockTower(100, 100, 'enemy')
        self.towers.add(self.king_tower_p)
        self.towers.add(self.king_tower_e)

def test_pushing_mechanic():
    pygame.init()
    game = MockGame()
    
    # Player units move UP (y decreases).
    
    # Set target
    target_pos = pygame.math.Vector2(100, 100)
    
    # Let's move King Towers out of the way for this test
    game.king_tower_e.pos = pygame.math.Vector2(500, 500) # Far away
    game.king_tower_p.pos = pygame.math.Vector2(500, 600)
    
    dummy_target = MockTower(100, 100, 'enemy', size=10)
    game.towers.add(dummy_target)
    
    # Spawn units closer to target to ensure they aggro
    # But far enough so they don't reach it quickly
    slow_unit = Unit(game, 100, 400, "knight", "player", network_id="slow") # Mass 20
    fast_unit = Unit(game, 100, 450, "hog_rider", "player", network_id="fast") # Mass 25
    
    slow_unit.target = dummy_target
    fast_unit.target = dummy_target
    
    # Update loop
    dt = 0.1
    
    # Initial distance
    initial_dist = fast_unit.pos.distance_to(slow_unit.pos) # 50
    print(f"Initial: Slow {slow_unit.pos.y}, Fast {fast_unit.pos.y}, Dist {initial_dist}")
    
    # Run until collision
    # Initial dist 50. Relative speed 8. Catch up in ~6 frames.
    # Run 8 frames to ensure collision but not passing (if pushing works)
    for i in range(8):
        slow_unit.update(dt)
        fast_unit.update(dt)
        # Force alignment to test pushing mechanic in isolation (avoid drift)
        slow_unit.pos.x = 100
        fast_unit.pos.x = 100
        slow_unit.rect.centerx = 100
        fast_unit.rect.centerx = 100
        print(f"Step {i}: Slow {slow_unit.pos.y}, Fast {fast_unit.pos.y}, Dist {fast_unit.pos.distance_to(slow_unit.pos)}")
    
    # Fast unit should catch up
    dist_after_catchup = fast_unit.pos.distance_to(slow_unit.pos)
    
    # They should be close (collision radius ~27.5)
    assert dist_after_catchup < initial_dist, f"Fast unit didn't catch up! Dist {dist_after_catchup}"
    
    # Now they should be colliding/pushing
    # Measure displacement of slow unit over next few frames
    start_y = slow_unit.pos.y
    
    for i in range(10):
        slow_unit.update(dt)
        fast_unit.update(dt)
        # Force alignment
        slow_unit.pos.x = 100
        fast_unit.pos.x = 100
        slow_unit.rect.centerx = 100
        fast_unit.rect.centerx = 100
        
    end_y = slow_unit.pos.y
    distance_moved = start_y - end_y # Moving UP (decreasing Y)
    
    print(f"Moved: {distance_moved}")
    
    # If pushed with low intensity, Fast unit might pass Slow unit.
    # This is now the desired behavior.
    # Verify that Fast unit is AHEAD of Slow unit (Y is smaller)
    assert fast_unit.pos.y < slow_unit.pos.y, f"Fast unit should pass Slow unit! Fast {fast_unit.pos.y}, Slow {slow_unit.pos.y}"
    
    # And Slow unit should still be moving roughly towards target (not stuck)
    # It might be slowed down by separation, but should recover.
    # assert distance_moved > 0, "Slow unit should keep moving"

def test_off_center_push_should_slide():
    pygame.init()
    game = MockGame()
    
    # Set target
    target_pos = pygame.math.Vector2(100, 100)
    
    game.king_tower_e.pos = pygame.math.Vector2(500, 500)
    game.king_tower_p.pos = pygame.math.Vector2(500, 600)
    
    dummy_target = MockTower(100, 100, 'enemy', size=10)
    game.towers.add(dummy_target)
    
    # Spawn units slightly off-center
    # Slow unit at 100, 400
    # Fast unit at 115, 450 (15px offset)
    # Collision radius approx 25+30/2 = 27.5
    # 15px offset is significant.
    
    slow_unit = Unit(game, 100, 400, "knight", "player", network_id="slow")
    fast_unit = Unit(game, 115, 450, "hog_rider", "player", network_id="fast")
    
    slow_unit.target = dummy_target
    fast_unit.target = dummy_target
    
    dt = 0.1
    
    # Run until collision
    for _ in range(20):
        slow_unit.update(dt)
        fast_unit.update(dt)
        
    # Now run more frames. They should slide past each other or separate, NOT push directly forward.
    # Slow unit should NOT be sped up significantly.
    
    start_y = slow_unit.pos.y
    for _ in range(10):
        slow_unit.update(dt)
        fast_unit.update(dt)
    end_y = slow_unit.pos.y
    
    distance_moved = start_y - end_y
    expected_base = slow_unit.speed * 1.0
    
    # Should be close to base speed (maybe slightly less due to friction/sliding, but definitely not pushed fast)
    assert distance_moved < expected_base * 1.2, f"Off-center unit should NOT be pushed fast! Moved {distance_moved}, expected base {expected_base}"

def test_lighter_cannot_push_heavier():
    pygame.init()
    game = MockGame()
    
    # Spawn Heavy Unit (Giant, mass 50)
    heavy_unit = Unit(game, 100, 300, "giant", "player", network_id="heavy")
    
    # Spawn Light Fast Unit (Goblin, mass 5, speed 5) behind
    light_unit = Unit(game, 100, 350, "goblin", "player", network_id="light")
    
    target_pos = pygame.math.Vector2(100, 0)
    dummy_target = type('obj', (object,), {'pos': target_pos, 'alive': lambda: True, 'team': 'enemy', 'unit_type': 'building', 'take_damage': lambda x: None})
    heavy_unit.target = dummy_target
    light_unit.target = dummy_target
    
    dt = 0.1
    
    # Run until collision
    for _ in range(30):
        heavy_unit.update(dt)
        light_unit.update(dt)
        
    # Measure displacement of heavy unit
    start_y = heavy_unit.pos.y
    for _ in range(10):
        heavy_unit.update(dt)
        light_unit.update(dt)
    end_y = heavy_unit.pos.y
    
    distance_moved = start_y - end_y
    expected_base = heavy_unit.speed * 1.0
    
    # Should NOT be significantly faster
    assert distance_moved < expected_base * 1.2, f"Heavy unit should NOT be pushed significantly. Moved {distance_moved}, expected base {expected_base}"

def test_head_on_collision_no_push():
    pygame.init()
    game = MockGame()
    
    # Two units moving towards each other
    u1 = Unit(game, 100, 300, "knight", "player", network_id="u1")
    u2 = Unit(game, 100, 400, "knight", "enemy", network_id="u2")
    
    u1.target = u2
    u2.target = u1
    
    dt = 0.1
    for _ in range(30):
        u1.update(dt)
        u2.update(dt)
        
    # They should stop/slide, not push each other through
    # Distance should be maintained (collision radius)
    dist = u1.pos.distance_to(u2.pos)
    min_dist = (u1.size/2 + u2.size/2)
    
    assert dist >= min_dist * 0.9, "Units should not phase through each other head-on"

def test_push_into_tower():
    pygame.init()
    game = MockGame()
    
    # Place a tower at (100, 100)
    tower = MockTower(100, 100, 'enemy', size=60)
    game.towers.add(tower)
    
    # Move King Towers away
    game.king_tower_e.pos = pygame.math.Vector2(500, 500)
    game.king_tower_p.pos = pygame.math.Vector2(500, 600)
    
    # Spawn Slow Unit (Knight) at (100, 160) - close to tower (radius 30 + 10 = 40)
    # 160 - 100 = 60. Dist 60. > 40.
    slow_unit = Unit(game, 100, 160, "knight", "player", network_id="slow")
    
    # Spawn Fast Unit (Hog) at (100, 210)
    fast_unit = Unit(game, 100, 210, "hog_rider", "player", network_id="fast")
    
    # Target behind tower
    target_pos = pygame.math.Vector2(100, 0)
    dummy_target = type('obj', (object,), {'pos': target_pos, 'alive': lambda: True, 'team': 'enemy', 'unit_type': 'building', 'take_damage': lambda x: None})
    
    slow_unit.target = dummy_target
    fast_unit.target = dummy_target
    
    dt = 0.1
    
    # Run until fast pushes slow into tower
    # Fast moves 12px/frame. Slow 4px/frame.
    # Dist 50. Catch up in ~7 frames.
    # Then push towards tower.
    # Tower at 100. Slow at 160.
    # Needs to move 60 - 40 = 20px to hit tower.
    # At 12px/frame, hits quickly.
    
    for i in range(30):
        slow_unit.update(dt)
        fast_unit.update(dt)
        # Force alignment to ensure we hit tower head-on
        slow_unit.pos.x = 100
        fast_unit.pos.x = 100
        slow_unit.rect.centerx = 100
        fast_unit.rect.centerx = 100
        
    # Check if slow unit is inside tower
    dist_to_tower = slow_unit.pos.distance_to(tower.pos)
    min_dist = (tower.size / 2) + (slow_unit.size / 2)
    
    # It should NOT be inside (dist < min_dist)
    # But due to "squish", it might be slightly inside if not handled.
    # The user wants it to be pushed to side.
    # So X should change?
    # But I forced X alignment in the loop!
    # If I force X alignment, I am preventing the fix (slide to side).
    # So I should NOT force X alignment in the last few frames, or check if it failed to slide.
    
    # Let's remove forced alignment for the last few frames to allow slide.
    
    # Rerun with alignment forced only initially
    slow_unit.pos = pygame.math.Vector2(100, 160)
    fast_unit.pos = pygame.math.Vector2(100, 210)
    
    for i in range(15): # Catch up and start pushing
        slow_unit.update(dt)
        fast_unit.update(dt)
        slow_unit.pos.x = 100
        fast_unit.pos.x = 100
        slow_unit.rect.centerx = 100
        fast_unit.rect.centerx = 100
        
    # Now let them hit the tower without forcing X
    for i in range(20):
        slow_unit.update(dt)
        fast_unit.update(dt)
        
    dist_to_tower = slow_unit.pos.distance_to(tower.pos)
    print(f"Final Dist to Tower: {dist_to_tower}, Min Dist: {min_dist}")
    print(f"Slow Unit Pos: {slow_unit.pos}")
    
    # It should be outside min_dist
    assert dist_to_tower >= min_dist * 0.95, f"Unit pushed into tower! Dist {dist_to_tower} < {min_dist}"
    
    # It should not have passed the tower (Y > 100)
    assert slow_unit.pos.y > 100, f"Unit passed through tower! Y: {slow_unit.pos.y}"
