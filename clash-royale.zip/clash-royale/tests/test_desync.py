import unittest
import pygame
import math
from unittest.mock import MagicMock
from game.core.managers import BattleManager
from game.entities.sprites import Unit, Tower
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT, HUD_HEIGHT

class TestDesync(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MagicMock()
        self.engine.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.host_game = BattleManager(self.engine)
        self.client_game = BattleManager(self.engine)
        self.playable_height = SCREEN_HEIGHT - HUD_HEIGHT
        
    def tearDown(self):
        pygame.quit()
        
    def get_mirrored_pos(self, x, y):
        return SCREEN_WIDTH - x, self.playable_height - y

    def test_skeleton_army_targeting(self):
        """Test that towers target the same skeleton in a swarm on both clients."""
        # Spawn a swarm on Host
        # We need to simulate how UnitCard.play spawns them.
        # Assuming it spawns them in a circle or grid.
        
        # Let's manually spawn 3 skeletons in a triangle on Host
        h_skels = []
        h_skels.append(Unit(self.host_game, 100, 200, "skeleton_army", "player"))
        h_skels.append(Unit(self.host_game, 110, 200, "skeleton_army", "player"))
        h_skels.append(Unit(self.host_game, 105, 210, "skeleton_army", "player"))
        
        # Spawn mirrored on Client
        c_skels = []
        for h in h_skels:
            mx, my = self.get_mirrored_pos(h.pos.x, h.pos.y)
            c_skels.append(Unit(self.client_game, mx, my, "skeleton_army", "enemy"))
            
        # Host Tower (Enemy King) targets Player Skeletons
        h_tower = self.host_game.king_tower_e
        
        # Client Tower (Player King) targets Enemy Skeletons
        c_tower = self.client_game.king_tower_p
        
        # Force find_target
        h_tower.find_target()
        c_tower.find_target()
        
        # Check which skeleton was targeted
        h_target = h_tower.target
        c_target = c_tower.target
        
        self.assertIsNotNone(h_target)
        self.assertIsNotNone(c_target)
        
        # Find the index of the targeted skeleton
        h_idx = h_skels.index(h_target)
        c_idx = c_skels.index(c_target)
        
        # They MUST be the same index (same logical unit)
        self.assertEqual(h_idx, c_idx, f"Host targeted skel {h_idx}, Client targeted skel {c_idx}")

if __name__ == '__main__':
    unittest.main()
