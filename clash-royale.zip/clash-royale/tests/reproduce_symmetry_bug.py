import unittest
import pygame
from game.core.managers import BattleManager
from game.entities.sprites import Unit
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT, HUD_HEIGHT, TILE_SIZE, GRID_MARGIN_X, GRID_MARGIN_Y
from game.core.symmetry import SymmetryUtils

class TestSymmetryBug(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = type('obj', (object,), {'virtual_surface': pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)), 'get_mouse_pos': lambda: (0,0)})
        self.host_game = BattleManager(self.engine)
        self.client_game = BattleManager(self.engine)
        self.playable_height = SCREEN_HEIGHT - HUD_HEIGHT

    def tearDown(self):
        pygame.quit()

    def test_spawn_symmetry(self):
        # Test spawning at various grid positions
        # We want to ensure that if Player spawns at (X, Y), Enemy sees it at (W-X, H-Y)
        # And crucially, that (W-X, H-Y) is also a valid grid center if (X, Y) was.
        
        # Let's pick a valid spawn position for the player
        # e.g. Left lane, near the bridge
        # Lane X is calculated in managers.py setup_arena
        # left_lane_x = GRID_MARGIN_X + LANE_LEFT_COL * TILE_SIZE + TILE_SIZE // 2
        
        # We can access the manager's calculated positions
        p_spawn_x = self.host_game.left_tower_p.pos.x
        p_spawn_y = self.host_game.left_tower_p.pos.y + 100 # Slightly below tower
        
        # Snap to grid first, as the game does
        p_snapped = self.host_game.snap_to_grid((p_spawn_x, p_spawn_y))
        
        print(f"Player spawns at: {p_snapped}")
        
        # Host spawns unit
        h_unit = Unit(self.host_game, p_snapped[0], p_snapped[1], "knight", "player")
        
        # Calculate expected enemy position
        expected_pos = SymmetryUtils.flip_pos(p_snapped)
        print(f"Expected Enemy pos: {expected_pos}")
        
        # Client receives spawn command
        # In the real game, the client receives the *original* pos and flips it? 
        # Or receives the flipped pos?
        # Let's assume the network sends the raw pos and the client flips it.
        # Or the server flips it.
        # If the client receives the *original* pos and flips it:
        c_pos = SymmetryUtils.flip_pos(p_snapped)
        
        # Create unit on client
        c_unit = Unit(self.client_game, c_pos[0], c_pos[1], "knight", "enemy")
        
        print(f"Client unit pos: {c_unit.pos}")
        
        # Verify symmetry
        self.assertEqual(c_unit.pos.x, expected_pos[0])
        self.assertEqual(c_unit.pos.y, expected_pos[1])
        
        # CRITICAL CHECK: Is the enemy position also centered on a tile?
        # If not, that's a bug.
        # We can check by trying to snap it and seeing if it changes.
        c_snapped = self.client_game.snap_to_grid(c_unit.pos)
        
        print(f"Client snapped pos: {c_snapped}")
        
        if c_unit.pos != c_snapped:
            print("BUG DETECTED: Enemy unit is not centered on a tile!")
            print(f"Diff: {c_unit.pos[0]-c_snapped[0]}, {c_unit.pos[1]-c_snapped[1]}")
            self.fail("Enemy unit is not centered on a tile")
            
        # Also check if the snapped position is the same as the flipped snapped position
        # i.e. is the grid symmetric?
        
if __name__ == '__main__':
    unittest.main()
