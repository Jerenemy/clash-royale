import unittest
from unittest.mock import MagicMock, patch
import sys
import os

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Mock pygame
mock_pygame = MagicMock()
mock_pygame.MOUSEBUTTONDOWN = 5
mock_pygame.MOUSEBUTTONUP = 6
mock_pygame.MOUSEMOTION = 4
mock_pygame.MOUSEWHEEL = 10
sys.modules['pygame'] = mock_pygame
sys.modules['pygame.font'] = MagicMock()
sys.modules['pygame.image'] = MagicMock()
sys.modules['pygame.transform'] = MagicMock()

import pygame # Import after mocking
from game.core.deck_builder import DeckBuilder

class MockRect:
    def __init__(self, x, y, w, h):
        self.x = x
        self.y = y
        self.width = w
        self.height = h
    
    @property
    def bottom(self): return self.y + self.height
    @property
    def top(self): return self.y
    @property
    def centerx(self): return self.x + self.width // 2
    @property
    def centery(self): return self.y + self.height // 2
    
    def collidepoint(self, pos):
        return self.x <= pos[0] <= self.x + self.width and self.y <= pos[1] <= self.y + self.height
        
    def copy(self):
        return MockRect(self.x, self.y, self.width, self.height)

class TestDeckBuilder(unittest.TestCase):
    def setUp(self):
        self.engine = MagicMock()
        self.engine.virtual_surface = MagicMock()
        self.engine.get_mouse_pos.return_value = (0, 0)
        
        # Patch UI classes to avoid pygame calls
        self.patcher1 = patch('game.core.deck_builder.Button', MagicMock())
        self.patcher2 = patch('game.core.deck_builder.Label', MagicMock())
        self.patcher3 = patch('game.core.deck_builder.CardButton')
        self.patcher4 = patch('game.core.deck_builder.UIManager', MagicMock())
        
        self.MockButton = self.patcher1.start()
        self.MockLabel = self.patcher2.start()
        self.MockCardButton = self.patcher3.start()
        self.MockUIManager = self.patcher4.start()
        self.engine.virtual_surface = MagicMock()
        
        # Make UI handle_event return False so we don't exit early
        self.MockUIManager.return_value.handle_event.return_value = False
        
        # Setup CardButton mock to behave like a rect-having object and handle clicks
        def card_btn_side_effect(*args, **kwargs):
            m = MagicMock()
            x = args[0] if len(args) > 0 else 0
            y = args[1] if len(args) > 1 else 0
            w = args[2] if len(args) > 2 else 95
            h = args[3] if len(args) > 3 else 125
            m.rect = MockRect(x, y, w, h)
            m.card_name = args[4] if len(args) > 4 else "unknown"
            m.visible = True
            
            on_click = kwargs.get('on_click')
            def mock_handle_event(event, pos):
                if event.type == pygame.MOUSEBUTTONUP:
                    if m.rect.collidepoint(pos):
                        if on_click: on_click()
                        return True
                return False
            m.handle_event.side_effect = mock_handle_event
            
            return m
        self.MockCardButton.side_effect = card_btn_side_effect

        # Mock UNIT_STATS and SPELL_STATS
        with patch('game.core.deck_builder.UNIT_STATS', {'unit1': {'cost': 1}, 'unit2': {'cost': 2}}), \
             patch('game.core.deck_builder.SPELL_STATS', {'spell1': {'cost': 3}}), \
             patch('game.core.deck_builder.load_deck', return_value=['unit1', 'unit2']), \
             patch('game.core.deck_builder.save_deck'):
            
            self.builder = DeckBuilder(self.engine)
            # Force available cards to be a known list
            self.builder.available_cards = ['unit1', 'unit2', 'spell1', 'card4', 'card5', 'card6']
            self.builder.create_buttons()

    def tearDown(self):
        self.patcher1.stop()
        self.patcher2.stop()
        self.patcher3.stop()
        self.patcher4.stop()

    def test_layout_no_gaps(self):
        """Test that collection buttons are laid out without gaps."""
        # Set deck to have unit1, unit2
        self.builder.deck = ['unit1', 'unit2']
        
        # Run update to trigger layout
        self.builder.update(0.016)
        
        # Check visible collection buttons (should not include unit1, unit2)
        visible_btns = [b for b in self.builder.card_buttons if b.visible]
        self.assertEqual(len(visible_btns), 4) # spell1, card4, card5, card6
        
        # Check positions
        # First visible button should be at start of collection area
        first_btn = visible_btns[0] # spell1
        
        # Calculate expected Y
        # Header (80) + 20 + Deck (2 rows) + 10 + Elixir (30) + Label (40)
        # Deck rows: 2 * (125 + 10) = 270
        # Deck top: 80 + 20 = 100
        # Deck bottom: 100 + 270 = 370
        # Elixir: 370 + 10 = 380
        # Label: 380 + 30 = 410
        # Collection start: 410 + 40 = 450
        
        expected_y = 450
        self.assertAlmostEqual(first_btn.rect.y, expected_y, delta=5)
        
        # Second visible button should be next to it (same Y, different X)
        second_btn = visible_btns[1]
        self.assertEqual(second_btn.rect.y, first_btn.rect.y)
        self.assertGreater(second_btn.rect.x, first_btn.rect.x)

    def test_scroll_updates_positions(self):
        """Test that scrolling updates button positions."""
        self.builder.update(0.016)
        initial_y = self.builder.deck_buttons[0].rect.y
        
        # Scroll down
        self.builder.scroll_offset = 100
        self.builder.update(0.016)
        
        new_y = self.builder.deck_buttons[0].rect.y
        self.assertEqual(new_y, initial_y - 100)

    def test_click_selects_card(self):
        """Test that clicking without dragging selects a card."""
        self.builder.deck = ['unit1']
        self.builder.update_deck_buttons()
        self.builder.update(0.016)
        
        # Get button position
        self.assertEqual(len(self.builder.deck_buttons), 1)
        btn = self.builder.deck_buttons[0]
        click_x = btn.rect.x + 10
        click_y = btn.rect.y + 10
        
        # Ensure mouse pos is correct for the event
        self.engine.get_mouse_pos.return_value = (click_x, click_y)
        
        # Simulate Click (Down, Up)
        self.builder.handle_event(MagicMock(type=pygame.MOUSEBUTTONDOWN, pos=(click_x, click_y)))
        self.builder.handle_event(MagicMock(type=pygame.MOUSEBUTTONUP, pos=(click_x, click_y)))
        
        self.assertEqual(self.builder.selected_card, 'unit1')

    def test_drag_threshold(self):
        """Test that small movements don't trigger drag, large ones do."""
        self.builder.deck = ['unit1']
        self.builder.update_deck_buttons()
        self.builder.update(0.016)
        
        btn = self.builder.deck_buttons[0]
        start_x = btn.rect.x + 10
        start_y = btn.rect.y + 10
        
        # 1. Small movement
        self.engine.get_mouse_pos.return_value = (start_x, start_y)
        self.builder.handle_event(MagicMock(type=pygame.MOUSEBUTTONDOWN, pos=(start_x, start_y)))
        
        self.engine.get_mouse_pos.return_value = (start_x + 2, start_y + 2)
        self.builder.handle_event(MagicMock(type=pygame.MOUSEMOTION, pos=(start_x + 2, start_y + 2)))
        
        self.assertIsNone(self.builder.dragging_card)
        
        # 2. Large movement
        self.engine.get_mouse_pos.return_value = (start_x + 10, start_y + 10)
        self.builder.handle_event(MagicMock(type=pygame.MOUSEMOTION, pos=(start_x + 10, start_y + 10)))
        
        self.assertEqual(self.builder.dragging_card, 'unit1')

if __name__ == '__main__':
    unittest.main()
