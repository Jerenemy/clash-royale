import unittest
import pygame
from game.core.arena import Arena
from game.settings import *

class MockTower:
    def __init__(self, alive=True):
        self._alive = alive
    def alive(self):
        return self._alive

class MockManager:
    def __init__(self):
        self.screen = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.playable_height = 620
        self.left_tower_e = MockTower(True)
        self.right_tower_e = MockTower(True)

class TestArena(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.manager = MockManager()
        self.arena = Arena(self.manager)

    def test_initialization(self):
        self.assertIsNotNone(self.arena.background)
        self.assertEqual(self.arena.grid_width, GRID_WIDTH)
        self.assertEqual(self.arena.grid_height, GRID_HEIGHT)

    def test_spawn_rects_basic(self):
        rects = self.arena.get_valid_spawn_rects()
        # Should have 1 rect (base area)
        self.assertEqual(len(rects), 1)
        
        # Check dimensions roughly
        base_rect = rects[0]
        self.assertEqual(base_rect.width, GRID_WIDTH * TILE_SIZE)
        self.assertTrue(base_rect.top > 0)

    def test_spawn_rects_pocket(self):
        # Kill left tower
        self.manager.left_tower_e = MockTower(False)
        rects = self.arena.get_valid_spawn_rects()
        # Should have 2 rects (base + left pocket)
        self.assertEqual(len(rects), 2)
        
        # Kill right tower
        self.manager.right_tower_e = MockTower(False)
        rects = self.arena.get_valid_spawn_rects()
        # Should have 3 rects (base + left + right)
        self.assertEqual(len(rects), 3)

    def test_geometry(self):
        """Test that river and bridges are calculated correctly."""
        # Expected values
        river_row_start = (GRID_HEIGHT // 2) - 1
        expected_river_y = river_row_start * TILE_SIZE
        expected_river_h = 2 * TILE_SIZE
        
        # Check River
        self.assertEqual(self.arena.river_rect.y, expected_river_y)
        self.assertEqual(self.arena.river_rect.height, expected_river_h)
        self.assertEqual(self.arena.river_rect.width, GRID_WIDTH * TILE_SIZE)
        
        # Check Bridges
        bridge_width = 3 * TILE_SIZE
        
        # Left Bridge
        self.assertEqual(self.arena.left_bridge_rect.centerx, 80)
        self.assertEqual(self.arena.left_bridge_rect.width, bridge_width)
        self.assertTrue(self.arena.left_bridge_rect.colliderect(self.arena.river_rect))
        
        # Right Bridge
        self.assertEqual(self.arena.right_bridge_rect.centerx, SCREEN_WIDTH - 80)
        self.assertEqual(self.arena.right_bridge_rect.width, bridge_width)
        self.assertTrue(self.arena.right_bridge_rect.colliderect(self.arena.river_rect))

    def test_draw(self):
        # Just ensure it doesn't crash
        surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.arena.draw(surface)

    def tearDown(self):
        pygame.quit()

if __name__ == "__main__":
    unittest.main()
