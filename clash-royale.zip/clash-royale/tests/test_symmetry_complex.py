import unittest
import pygame
import math
from unittest.mock import MagicMock
from game.core.managers import BattleManager
from game.entities.sprites import Unit, FlyingUnit
from game.core.symmetry import SymmetryUtils
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT

class TestSymmetryComplex(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.mock_engine = MagicMock()
        self.mock_engine.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.manager = BattleManager(self.mock_engine)
        self.manager.playable_height = 620
        
    def test_swarm_vs_swarm_symmetry(self):
        """
        Simulate a mirrored battle with Swarms (Minions) and verify symmetry.
        """
        # Spawn Minions (Flying Swarm)
        # Player: Right Lane (approx 350, 500)
        # Enemy: Left Lane (Mirrored)
        
        p_center = (350, 500)
        e_center = SymmetryUtils.flip_pos(p_center)
        
        # Create units manually to simulate swarm spawn
        # Minions count = 3
        count = 3
        radius = 30
        
        p_units = []
        e_units = []
        
        for i in range(count):
            # Player
            angle_p = (2 * math.pi / count) * i
            angle_p = SymmetryUtils.transform_formation_angle(angle_p, "player")
            ox_p = math.cos(angle_p) * radius
            oy_p = math.sin(angle_p) * radius
            
            u_p = FlyingUnit(self.manager, p_center[0] + ox_p, p_center[1] + oy_p, "minions", "player", network_id=f"p_minion_{i}")
            p_units.append(u_p)
            
            # Enemy
            angle_e = (2 * math.pi / count) * i
            angle_e = SymmetryUtils.transform_formation_angle(angle_e, "enemy")
            ox_e = math.cos(angle_e) * radius
            oy_e = math.sin(angle_e) * radius
            
            u_e = FlyingUnit(self.manager, e_center[0] + ox_e, e_center[1] + oy_e, "minions", "enemy", network_id=f"e_minion_{i}")
            e_units.append(u_e)
            
        # Verify initial positions are mirrored
        for i in range(count):
            self.assertAlmostEqual(p_units[i].pos.x, SymmetryUtils.flip_x(e_units[i].pos.x), places=4)
            self.assertAlmostEqual(p_units[i].pos.y, SymmetryUtils.flip_y(e_units[i].pos.y), places=4)
            
        # Run simulation
        # They should fly towards towers.
        # Player -> Enemy Left Tower
        # Enemy -> Player Right Tower
        
        # We need to check if they deal damage symmetrically.
        # This requires them to reach the tower and attack.
        # Minions are fast (speed 4 -> 80 px/sec).
        # Distance approx 400 px. ~5 seconds.
        # 300 frames.
        
        for frame in range(400):
            self.manager.update(0.016)
            
            # Check Unit Symmetry
            for i in range(count):
                if p_units[i].alive() and e_units[i].alive():
                    self.assertAlmostEqual(p_units[i].pos.x, SymmetryUtils.flip_x(e_units[i].pos.x), delta=0.1, msg=f"Pos Asymmetry Frame {frame} Unit {i}")
                    self.assertAlmostEqual(p_units[i].pos.y, SymmetryUtils.flip_y(e_units[i].pos.y), delta=0.1, msg=f"Pos Asymmetry Frame {frame} Unit {i}")
                    self.assertEqual(p_units[i].health, e_units[i].health, f"Health Asymmetry Frame {frame} Unit {i}")
            
            # Check Tower Symmetry
            # Player Left Tower vs Enemy Right Tower
            # Player Right Tower vs Enemy Left Tower
            
            # p_units are attacking Enemy Left Tower (manager.left_tower_e)
            # e_units are attacking Player Right Tower (manager.right_tower_p)
            
            t_e_left = self.manager.left_tower_e
            t_p_right = self.manager.right_tower_p
            
            self.assertEqual(t_e_left.health, t_p_right.health, f"Tower Health Asymmetry Frame {frame}: E_Left={t_e_left.health}, P_Right={t_p_right.health}")

if __name__ == '__main__':
    unittest.main()
