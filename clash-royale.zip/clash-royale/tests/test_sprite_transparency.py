import unittest
import pygame
from game.entities.geometric_sprites import geometric_renderer, KnightSprite

class TestSpriteTransparency(unittest.TestCase):
    def setUp(self):
        pygame.init()
        # Create a dummy display to ensure convert_alpha works as expected
        self.display = pygame.display.set_mode((100, 100), pygame.HIDDEN)
        
    def test_sprite_background_is_transparent(self):
        # Get a knight sprite
        # Force render a new one to bypass cache potentially, or just use renderer
        sprite = geometric_renderer.get_sprite("knight", "player", 0, 270)
        
        # Check corners for transparency
        width, height = sprite.get_size()
        
        # Top-left
        tl = sprite.get_at((0, 0))
        # Top-right
        tr = sprite.get_at((width-1, 0))
        # Bottom-left
        bl = sprite.get_at((0, height-1))
        # Bottom-right
        br = sprite.get_at((width-1, height-1))
        
        print(f"Top-Left Pixel: {tl}")
        
        # Should be (0, 0, 0, 0)
        self.assertEqual(tl.a, 0, f"Top-left pixel alpha should be 0, got {tl.a}")
        self.assertEqual(tr.a, 0, "Top-right pixel alpha should be 0")
        self.assertEqual(bl.a, 0, "Bottom-left pixel alpha should be 0")
        self.assertEqual(br.a, 0, "Bottom-right pixel alpha should be 0")
        
    def test_ghost_transparency(self):
        """Simulate the ghost rendering process"""
        sprite = geometric_renderer.get_sprite("knight", "player", 0, 270)
        ghost = sprite.copy()
        ghost.set_alpha(150)
        
        # Blit onto a white background
        bg = pygame.Surface((100, 100))
        bg.fill((255, 255, 255))
        
        rect = ghost.get_rect(center=(50, 50))
        bg.blit(ghost, rect)
        
        # Check a pixel that should be background (corner of sprite rect)
        # It should still be white (background), not darkened by the ghost's bounding box
        # The ghost's bounding box is rect.
        # Let's check pixel at rect.topleft
        
        bg_pixel = bg.get_at(rect.topleft)
        print(f"Background pixel at sprite corner: {bg_pixel}")
        
        # If the sprite background was transparent (0,0,0,0), 
        # blitting it with set_alpha(150) should NOT affect the destination pixels 
        # where the source alpha is 0.
        # Pygame blit: 
        # If source has per-pixel alpha, set_alpha is combined?
        # "If the source surface has per-pixel alpha, the surface alpha is combined with the per-pixel alpha."
        # So 0 * 150/255 = 0.
        # So it should remain transparent.
        
        self.assertEqual(bg_pixel, (255, 255, 255, 255), 
                        f"Pixel at sprite corner should be white, got {bg_pixel}. This implies the sprite background is not fully transparent.")

if __name__ == '__main__':
    unittest.main()
