import unittest
from unittest.mock import MagicMock
from game.network.controller import NetworkController
from game.settings import SCREEN_WIDTH, HUD_HEIGHT, SCREEN_HEIGHT

class TestMultiplayerCoords(unittest.TestCase):
    def setUp(self):
        self.mock_manager = MagicMock()
        self.mock_manager.playable_height = SCREEN_HEIGHT - HUD_HEIGHT
        self.mock_client = MagicMock()
        self.controller = NetworkController(self.mock_manager, self.mock_client, "player")
        
    def test_coordinate_flip(self):
        """Test that coordinates are flipped correctly for the enemy."""
        # Define a play position (e.g., near player's bottom-left)
        # x = 100, y = 600 (assuming playable_height is ~780)
        pos_x = 100
        pos_y = 600
        
        data = {
            "card_name": "knight",
            "pos_x": pos_x,
            "pos_y": pos_y,
            "side": "enemy", # Sender is enemy
            "network_ids": ["123"]
        }
        
        # Call the handler directly
        self.controller._handle_remote_play_card(data)
        
        # Verify spawn_card was called with flipped coordinates
        # Expected X: SCREEN_WIDTH - 100
        # Expected Y: playable_height - 600
        expected_x = SCREEN_WIDTH - 100
        expected_y = self.mock_manager.playable_height - 600
        
        self.mock_manager.spawn_card.assert_called_once()
        args = self.mock_manager.spawn_card.call_args
        spawn_pos = args[0][1] # 2nd arg is pos
        
        self.assertEqual(spawn_pos[0], expected_x)
        self.assertEqual(spawn_pos[1], expected_y)
        
    def test_bridge_symmetry(self):
        """Test that a point at the river/bridge flips to the same Y (relative to center)."""
        # River is roughly at playable_height / 2
        mid_y = self.mock_manager.playable_height / 2
        
        data = {
            "card_name": "knight",
            "pos_x": 100,
            "pos_y": mid_y,
            "side": "enemy"
        }
        
        self.controller._handle_remote_play_card(data)
        
        args = self.mock_manager.spawn_card.call_args
        spawn_pos = args[0][1]
        
        # Should be flipped around center, so if it was at center, it stays at center
        self.assertAlmostEqual(spawn_pos[1], mid_y)

if __name__ == '__main__':
    unittest.main()
