import pytest
import pygame
import math
from game.core.game import Game
from game.entities.sprites import Unit
from game.settings import *

class MockTower(pygame.sprite.Sprite):
    def __init__(self, x, y, team, size=60):
        super().__init__()
        self.pos = pygame.math.Vector2(x, y)
        self.rect = pygame.Rect(x, y, size, size)
        self.rect.center = (x, y)
        self.team = team
        self.size = size
        self.alive = lambda: True
        
    def take_damage(self, amount):
        pass

class MockGame:
    def __init__(self):
        self.units = pygame.sprite.Group()
        self.towers = pygame.sprite.Group()
        self.all_sprites = pygame.sprite.Group()
        self.projectiles = pygame.sprite.Group()
        self.playable_height = 620
        
        # Mock towers for targeting
        self.king_tower_p = MockTower(100, 700, 'player')
        self.king_tower_e = MockTower(100, 100, 'enemy')
        self.towers.add(self.king_tower_p)
        self.towers.add(self.king_tower_e)

def test_ground_unit_collision():
    pygame.init()
    game = MockGame()
    
    # Spawn two knights facing each other
    # Knight size is 25
    u1 = Unit(game, 100, 300, "knight", "player", network_id="u1")
    u2 = Unit(game, 140, 300, "knight", "enemy", network_id="u2")
    
    # Force them to move towards each other
    u1.target = u2
    u2.target = u1
    
    # Update for some frames
    dt = 0.1
    for _ in range(20):
        u1.update(dt)
        u2.update(dt)
        
    # Check distance
    dist = u1.pos.distance_to(u2.pos)
    min_dist = (u1.size / 2) + (u2.size / 2)
    
    # They should be touching or very close, but not significantly overlapping
    # Allow small overlap due to push-out logic not being instant rigid body physics
    assert dist >= min_dist * 0.8, f"Units overlapped too much: dist={dist}, min={min_dist}"
    
def test_nudge_retargeting():
    pygame.init()
    game = MockGame()
    
    # Spawn a unit with a far target
    u1 = Unit(game, 100, 300, "knight", "player", network_id="u1")
    far_target = Unit(game, 100, 600, "knight", "enemy", network_id="far") # Far away
    u1.target = far_target
    
    # Verify initial state
    assert u1.nudged == False
    
    # Spawn a unit right on top of u1 to force collision
    u2 = Unit(game, 100, 300, "knight", "player", network_id="u2") # Same team collision
    
    # Update u1
    u1.update(0.1)
    
    # Check if nudged was set (it resets at end of update, so we might miss it if we check after update)
    # Wait, my implementation resets nudged AFTER the check but BEFORE movement.
    # So if collision happens during movement, nudged will be True at the end of the frame.
    
    assert u1.nudged == True, "Unit should be nudged after collision"
    
def test_air_unit_soft_collision():
    pygame.init()
    game = MockGame()
    
    # Spawn two air units (Baby Dragon, size 30)
    u1 = Unit(game, 100, 300, "baby_dragon", "player", network_id="u1")
    u2 = Unit(game, 100, 300, "baby_dragon", "player", network_id="u2")
    
    # Update
    u1.update(0.1)
    
    # Air units use soft separation, so nudged should NOT be set unless separation is huge
    # My code: if separation.length() > 0.5: self.nudged = True
    # If they are on top of each other, separation will be large.
    
    # Let's test they separate
    initial_dist = u1.pos.distance_to(u2.pos) # 0
    
    for _ in range(10):
        u1.update(0.1)
        u2.update(0.1)
        
    final_dist = u1.pos.distance_to(u2.pos)
    assert final_dist > initial_dist, "Air units should separate"
