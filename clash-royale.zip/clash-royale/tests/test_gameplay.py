import unittest
import pygame
from unittest.mock import MagicMock, patch

# Initialize pygame for tests
pygame.init()
pygame.display.set_mode((1, 1))

from game.core.managers import BattleManager
from game.core.card import UnitCard, SpellCard
from game.models import Player
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT

class TestGameplay(unittest.TestCase):
    def setUp(self):
        self.screen = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.mock_engine = MagicMock()
        self.mock_engine.virtual_surface = self.screen
        self.mock_engine.get_mouse_pos.return_value = (0, 0)
        self.manager = BattleManager(self.mock_engine)
        
        # Mock player deck/hand for deterministic testing
        self.manager.player.elixir = 10
        self.manager.player.hand = [
            UnitCard("knight", {"cost": 3, "unit_type": "ground", "health": 100, "damage": 10, "attack_speed": 1.0, "speed": 1.0, "range": 1, "color": (0,0,255)}),
            SpellCard("fireball", {"cost": 4, "radius": 50, "damage": 100, "color": (255,0,0)})
        ]
        self.manager.player.next_card = UnitCard("archer", {"cost": 3, "unit_type": "ground", "health": 50, "damage": 10, "attack_speed": 1.0, "speed": 1.0, "range": 5, "color": (0,255,0)})

    def test_game_loop_step(self):
        """Test a single update step of the battle manager."""
        try:
            self.manager.update(0.016)
        except Exception as e:
            self.fail(f"BattleManager.update() raised exception: {e}")

    def test_play_unit_card(self):
        """Test playing a unit card."""
        # Select first card (knight)
        self.manager.dragging_card_idx = 0
        
        # Play it at a valid position
        pos = (100, 600) # Player side (playable_height is ~780)
        
        try:
            self.manager.try_play_card(pos)
        except Exception as e:
            self.fail(f"try_play_card (Unit) raised exception: {e}")
            
        # Verify card was played (hand changed)
        self.assertNotEqual(self.manager.player.hand[0].name, "knight")
        self.assertEqual(len(self.manager.units), 1) # Knight spawned
        # Actually BattleManager setup_arena creates towers.
        # So len should be > 0.

    def test_play_spell_card(self):
        """Test playing a spell card."""
        # Select second card (fireball)
        self.manager.dragging_card_idx = 1
        
        # Play it anywhere
        pos = (300, 300)
        
        try:
            self.manager.try_play_card(pos)
        except Exception as e:
            self.fail(f"try_play_card (Spell) raised exception: {e}")
            
        # Verify card was played
        self.assertNotEqual(self.manager.player.hand[1].name, "fireball")

    def test_draw_frame(self):
        """Test drawing a frame."""
        try:
            self.manager.draw()
        except Exception as e:
            self.fail(f"BattleManager.draw() raised exception: {e}")

if __name__ == '__main__':
    unittest.main()
