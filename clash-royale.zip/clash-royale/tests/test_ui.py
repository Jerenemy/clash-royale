import unittest
import pygame
from game.models import Player
from game.core.managers import BattleManager
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT

class MockEngine:
    def __init__(self, screen):
        self.virtual_surface = screen
        self.get_mouse_pos = lambda: (0, 0)

class TestUIDrawing(unittest.TestCase):
    def setUp(self):
        pygame.init()
        # Initialize a hidden display for convert_alpha() to work
        pygame.display.set_mode((1, 1), pygame.NOFRAME)
        self.screen = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.engine = MockEngine(self.screen)
        self.manager = BattleManager(self.engine)
        # Force a hand with cards
        self.manager.player.elixir = 10

    def test_draw_hud_no_error(self):
        """Test that draw_hud runs without error with Card objects in hand."""
        try:
            self.manager.draw_hud()
        except Exception as e:
            self.fail(f"draw_hud raised exception: {e}")

    def test_drag_visual_no_error(self):
        """Test that drag visual runs without error."""
        self.manager.dragging_card_idx = 0
        self.manager.drag_pos = (100, 100)
        try:
            self.manager.draw_hud()
        except Exception as e:
            self.fail(f"draw_hud with drag raised exception: {e}")

if __name__ == '__main__':
    unittest.main()
