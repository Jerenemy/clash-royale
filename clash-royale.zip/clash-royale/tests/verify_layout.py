import pygame
import sys
import os

# Add game directory to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from game.settings import *
from game.core.arena import Arena
from game.core.managers import BattleManager

# Mock classes
class MockEngine:
    def __init__(self):
        self.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.mouse_pos = (0, 0)
    def get_mouse_pos(self): return self.mouse_pos

def verify_layout():
    pygame.init()
    
    # Setup
    engine = MockEngine()
    manager = BattleManager(engine)
    arena = manager.arena
    
    # Create a surface to draw on
    surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    surface.fill((50, 50, 50)) # Dark background
    
    # Draw Arena Background (Grid, River, Bridges)
    arena.draw(surface)
    
    # Draw Towers
    for tower in manager.towers:
        color = (0, 0, 255) if tower.team == "player" else (255, 0, 0)
        pygame.draw.rect(surface, color, tower.rect)
        # Draw center point
        pygame.draw.circle(surface, (255, 255, 255), tower.rect.center, 3)
        
    # Draw Lane Guidelines (Columns 3 and 14)
    # Left Lane (Index 3)
    lane_left_x = GRID_MARGIN_X + 3 * TILE_SIZE + TILE_SIZE // 2
    pygame.draw.line(surface, (255, 255, 0), (lane_left_x, 0), (lane_left_x, SCREEN_HEIGHT), 1)
    
    # Right Lane (Index 14)
    # 18 columns total. Indices 0-17.
    # 3 blocks in from right = Index 14 (17, 16, 15 are the 3 blocks? Or 14 is the 4th?)
    # "3 blocks in" usually means 3 empty blocks.
    # Left: 0, 1, 2 are empty. Lane is at 3.
    # Right: 17, 16, 15 are empty. Lane is at 14.
    lane_right_x = GRID_MARGIN_X + 14 * TILE_SIZE + TILE_SIZE // 2
    pygame.draw.line(surface, (255, 255, 0), (lane_right_x, 0), (lane_right_x, SCREEN_HEIGHT), 1)
    
    # Save image
    pygame.image.save(surface, "layout_verification.png")
    print("Saved layout_verification.png")
    
    # Assertions
    print("Verifying dimensions...")
    
    # Check Bridge Width
    bridge_w = arena.left_bridge_rect.width
    print(f"Bridge Width: {bridge_w} (Expected: {TILE_SIZE})")
    
    # Check Bridge Positions relative to lanes
    print(f"Left Bridge Center X: {arena.left_bridge_rect.centerx} (Expected: {lane_left_x})")
    print(f"Right Bridge Center X: {arena.right_bridge_rect.centerx} (Expected: {lane_right_x})")
    
    # Check Tower Sizes
    p_tower = manager.left_tower_p
    print(f"Princess Tower Width: {p_tower.rect.width} (Expected: ~{3 * TILE_SIZE})")
    
    # Check Tower Alignment
    print(f"Left Princess Tower Center X: {p_tower.rect.centerx} (Expected: {lane_left_x})")

if __name__ == "__main__":
    verify_layout()
