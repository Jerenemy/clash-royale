import unittest
import pygame
from game.core.managers import BattleManager
from game.core.symmetry import SymmetryUtils
from game.entities.sprites import Unit
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT, GRID_MARGIN_Y, GRID_HEIGHT, TILE_SIZE

class TestTowerAsymmetry(unittest.TestCase):
    def setUp(self):
        pygame.init()
        # Mock engine
        self.engine = type('Engine', (), {'virtual_surface': pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)), 'get_mouse_pos': lambda: (0,0)})()
        self.manager = BattleManager(self.engine)
        
        # Disable random seed for determinism
        import random
        random.seed(42)

    def test_tower_interaction_symmetry(self):
        """
        Simulate a mirrored battle involving towers:
        - Player spawns Musketeer (ranged) near Enemy Left Tower.
        - Enemy spawns Musketeer (ranged) near Player Right Tower (Mirrored).
        
        We expect:
        - Both Musketeers to lock onto the tower at the same time.
        - Both Towers to lock onto the Musketeers at the same time.
        - Damage to be applied symmetrically.
        """
        
        # Lane positions
        left_lane_x = 100 
        right_lane_x = SCREEN_WIDTH - 100
        
        bridge_y = GRID_MARGIN_Y + (GRID_HEIGHT * TILE_SIZE) / 2.0
        
        # Spawn positions: Just across the bridge, within range of tower?
        # Musketeer range is 9 tiles. Tower range is 11.6 tiles.
        # Let's spawn them such that they walk into range.
        
        p_spawn_pos = (left_lane_x, bridge_y - 100) # Player unit moving UP towards Enemy Tower
        e_spawn_pos = SymmetryUtils.flip_pos(p_spawn_pos) # Enemy unit moving DOWN towards Player Tower
        
        self.manager.spawn_card("musketeer", p_spawn_pos, "player", network_ids=["p_musk"])
        self.manager.spawn_card("musketeer", e_spawn_pos, "enemy", network_ids=["e_musk"])
        
        # Run simulation
        for frame in range(600): # 10 seconds
            self.manager.update(0.016)
            
            # Check Tower Health Symmetry
            hp_p = self.manager.right_tower_p.health # Enemy attacks this
            hp_e = self.manager.left_tower_e.health # Player attacks this
            
            if hp_p != hp_e:
                print(f"Frame {frame} Tower HP Asymmetry: P_Tower={hp_p} E_Tower={hp_e}")
                self.assertEqual(hp_p, hp_e, f"Tower HP mismatch at frame {frame}")
                
            # Check Unit Health Symmetry
            p_unit = next((u for u in self.manager.units if u.network_id == "p_musk"), None)
            e_unit = next((u for u in self.manager.units if u.network_id == "e_musk"), None)
            
            if p_unit and e_unit:
                if p_unit.health != e_unit.health:
                    print(f"Frame {frame} Unit HP Asymmetry: P={p_unit.health} E={e_unit.health}")
                    self.assertEqual(p_unit.health, e_unit.health, f"Unit HP mismatch at frame {frame}")
            elif p_unit or e_unit:
                 # One died but not the other
                 self.fail(f"Unit Survival Asymmetry at frame {frame}: P={p_unit is not None} E={e_unit is not None}")

if __name__ == "__main__":
    unittest.main()
