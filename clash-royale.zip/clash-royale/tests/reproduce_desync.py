
import unittest
import pygame
import math
from game.core.managers import BattleManager
from game.entities.sprites import Unit
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT

class MockEngine:
    def __init__(self):
        self.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.mouse_pos = (0, 0)
    
    def get_mouse_pos(self):
        return self.mouse_pos

class TestSymmetry(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MockEngine()
        self.manager = BattleManager(self.engine, practice_mode=False)
        
    def test_swarm_symmetry(self):
        # Spawn two units at mirrored positions
        # River is at 310 (620 // 2)
        # Player side: Y > 310
        # Enemy side: Y < 310
        
        center_y = 310
        offset_y = 90
        
        # Spawn Player Unit at (100, 400)
        u1 = Unit(self.manager, 100, center_y + offset_y, "knight", "player", network_id="p1")
        
        # Spawn Enemy Unit at (380, 220)
        u2 = Unit(self.manager, SCREEN_WIDTH - 100, center_y - offset_y, "knight", "enemy", network_id="e1")
        
        # Run simulation
        dt = 0.016
        for _ in range(300):
            self.manager.update(dt)
            
        # Check positions
        # They should be mirrored relative to center
        center_x = SCREEN_WIDTH / 2
        
        dist_from_center_x_1 = center_x - u1.pos.x
        dist_from_center_x_2 = u2.pos.x - center_x
        
        dist_from_center_y_1 = u1.pos.y - center_y
        dist_from_center_y_2 = center_y - u2.pos.y
        
        print(f"P1: {u1.pos}, E1: {u2.pos}")
        print(f"Dist X: {dist_from_center_x_1} vs {dist_from_center_x_2}")
        print(f"Dist Y: {dist_from_center_y_1} vs {dist_from_center_y_2}")
        
        self.assertAlmostEqual(dist_from_center_x_1, dist_from_center_x_2, delta=0.1, msg="X Symmetry broken")
        self.assertAlmostEqual(dist_from_center_y_1, dist_from_center_y_2, delta=0.1, msg="Y Symmetry broken")

    def test_flying_symmetry(self):
        # Test FlyingUnit symmetry (which had the bug)
        from game.entities.sprites import FlyingUnit
        
        center_y = 310
        offset_y = 90
        
        # Spawn Player Minions
        u1 = FlyingUnit(self.manager, 100, center_y + offset_y, "minions", "player", network_id="p1")
        
        # Spawn Enemy Minions
        u2 = FlyingUnit(self.manager, SCREEN_WIDTH - 100, center_y - offset_y, "minions", "enemy", network_id="e1")
        
        # Run simulation
        dt = 0.016
        for _ in range(300):
            self.manager.update(dt)
            
        # Check positions
        center_x = SCREEN_WIDTH / 2
        
        dist_from_center_x_1 = center_x - u1.pos.x
        dist_from_center_x_2 = u2.pos.x - center_x
        
        dist_from_center_y_1 = u1.pos.y - center_y
        dist_from_center_y_2 = center_y - u2.pos.y
        
        print(f"Flying P1: {u1.pos}, E1: {u2.pos}")
        
        self.assertAlmostEqual(dist_from_center_x_1, dist_from_center_x_2, delta=0.1, msg="Flying X Symmetry broken")
        self.assertAlmostEqual(dist_from_center_y_1, dist_from_center_y_2, delta=0.1, msg="Flying Y Symmetry broken")


if __name__ == '__main__':
    unittest.main()
