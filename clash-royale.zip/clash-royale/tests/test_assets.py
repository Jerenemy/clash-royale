import unittest
import pygame
import os
from game.assets import assets
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT

class TestAssetLoading(unittest.TestCase):
    def setUp(self):
        # Initialize pygame display (headless if possible, but for assets we need a mode)
        pygame.init()
        # Set a dummy mode to allow image conversion
        pygame.display.set_mode((100, 100))
        
    def tearDown(self):
        pygame.quit()
        
    def test_load_assets(self):
        """Test that assets can be loaded without error."""
        # Ensure assets directory exists (it should from previous steps)
        if not os.path.exists("assets"):
            os.makedirs("assets")
            
        # Create dummy files if they don't exist to avoid failure
        dummy_files = ["arena_map.png", "loading_screen.png", "menu_background.png"]
        for f in dummy_files:
            path = os.path.join("assets", f)
            if not os.path.exists(path):
                s = pygame.Surface((10, 10))
                pygame.image.save(s, path)
                
        # Try loading assets
        try:
            assets.load_game_assets()
        except Exception as e:
            self.fail(f"load_game_assets raised exception: {e}")
            
        # Verify images are loaded
        self.assertIsNotNone(assets.get_image("arena_map"))
        self.assertIsNotNone(assets.get_image("loading_screen"))
        self.assertIsNotNone(assets.get_image("menu_background"))

if __name__ == '__main__':
    unittest.main()
