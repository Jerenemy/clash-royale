"""
Unit Tests for Network Protocol

Tests message encoding, decoding, and helper functions.
"""

import unittest
import json
from network_protocol import (
    Message, MessageType, ActionType,
    encode_message, decode_message,
    create_queue_join_message, create_match_found_message,
    create_game_action_message, create_disconnect_message
)


class TestNetworkProtocol(unittest.TestCase):
    """Test cases for network protocol"""
    
    def test_message_creation(self):
        """Test creating a message"""
        msg = Message(MessageType.QUEUE_JOIN, {"player_id": "test123"})
        
        self.assertEqual(msg.type, MessageType.QUEUE_JOIN.value)
        self.assertEqual(msg.data["player_id"], "test123")
        self.assertIsNotNone(msg.timestamp)
    
    def test_message_to_dict(self):
        """Test converting message to dictionary"""
        msg = Message(MessageType.GAME_ACTION, {"action": "test"})
        d = msg.to_dict()
        
        self.assertIn("type", d)
        self.assertIn("data", d)
        self.assertIn("timestamp", d)
        self.assertEqual(d["type"], MessageType.GAME_ACTION.value)
    
    def test_message_from_dict(self):
        """Test creating message from dictionary"""
        d = {
            "type": "queue_join",
            "data": {"player_id": "abc"},
            "timestamp": 12345.0
        }
        
        msg = Message.from_dict(d)
        
        self.assertEqual(msg.type, "queue_join")
        self.assertEqual(msg.data["player_id"], "abc")
        self.assertEqual(msg.timestamp, 12345.0)
    
    def test_encode_decode_roundtrip(self):
        """Test encoding and decoding a message"""
        original_msg = Message(MessageType.MATCH_FOUND, {
            "opponent_id": "player456",
            "side": "player"
        })
        
        # Encode
        encoded = encode_message(original_msg)
        
        # Check format (4-byte length prefix + JSON)
        self.assertIsInstance(encoded, bytes)
        self.assertGreater(len(encoded), 4)
        
        # Decode (skip length prefix)
        length = int.from_bytes(encoded[:4], byteorder='big')
        decoded_msg = decode_message(encoded[4:])
        
        # Verify
        self.assertEqual(decoded_msg.type, original_msg.type)
        self.assertEqual(decoded_msg.data, original_msg.data)
    
    def test_create_queue_join_message(self):
        """Test creating queue join message"""
        msg = create_queue_join_message("player1", ["knight", "archer"])
        
        self.assertEqual(msg.type, MessageType.QUEUE_JOIN.value)
        self.assertEqual(msg.data["player_id"], "player1")
        self.assertEqual(msg.data["deck"], ["knight", "archer"])
    
    def test_create_match_found_message(self):
        """Test creating match found message"""
        msg = create_match_found_message("player1", "player2", "player")
        
        self.assertEqual(msg.type, MessageType.MATCH_FOUND.value)
        self.assertEqual(msg.data["player_id"], "player1")
        self.assertEqual(msg.data["opponent_id"], "player2")
        self.assertEqual(msg.data["side"], "player")
    
    def test_create_game_action_message(self):
        """Test creating game action message"""
        action_data = {"card_name": "knight", "pos_x": 100, "pos_y": 200}
        msg = create_game_action_message("player1", ActionType.PLAY_CARD, action_data)
        
        self.assertEqual(msg.type, MessageType.GAME_ACTION.value)
        self.assertEqual(msg.data["player_id"], "player1")
        self.assertEqual(msg.data["action_type"], ActionType.PLAY_CARD.value)
        self.assertEqual(msg.data["action_data"], action_data)
    
    def test_create_disconnect_message(self):
        """Test creating disconnect message"""
        msg = create_disconnect_message("player1", "timeout")
        
        self.assertEqual(msg.type, MessageType.DISCONNECT.value)
        self.assertEqual(msg.data["player_id"], "player1")
        self.assertEqual(msg.data["reason"], "timeout")
    
    def test_decode_invalid_message(self):
        """Test decoding invalid message data"""
        invalid_data = b"not json"
        
        result = decode_message(invalid_data)
        
        self.assertIsNone(result)
    
    def test_encode_dict_directly(self):
        """Test encoding a dictionary directly"""
        d = {"type": "test", "data": {"key": "value"}}
        
        encoded = encode_message(d)
        
        self.assertIsInstance(encoded, bytes)
        # Verify it can be decoded
        length = int.from_bytes(encoded[:4], byteorder='big')
        decoded = decode_message(encoded[4:])
        self.assertIsNotNone(decoded)


if __name__ == "__main__":
    unittest.main()
