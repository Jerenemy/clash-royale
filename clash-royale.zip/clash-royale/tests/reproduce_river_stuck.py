import unittest
import pygame
import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from game.settings import *
from game.core.managers import BattleManager
from game.entities.sprites import Unit

class MockEngine:
    def __init__(self):
        self.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    def get_mouse_pos(self):
        return (0, 0)

class TestRiverStuck(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MockEngine()
        self.manager = BattleManager(self.engine)
        self.arena = self.manager.arena

    def test_diagonal_river_entry(self):
        # Spawn a unit in the center of the map, below the river
        # River is at Y ~ 400
        start_x = SCREEN_WIDTH // 2
        start_y = 600
        unit = Unit(self.manager, start_x, start_y, "giant", "player")
        
        # Target: Enemy King Tower (Top Center)
        unit.target = self.manager.king_tower_e
        
        # Simulate movement
        dt = 0.1
        steps = 300 # 30 seconds
        
        entered_river_illegally = False
        
        print(f"River Rect: {self.arena.river_rect}")
        print(f"Left Bridge: {self.arena.left_bridge_rect}")
        print(f"Right Bridge: {self.arena.right_bridge_rect}")
        
        for i in range(steps):
            unit.update(dt)
            
            # Check if unit is in river rect
            if self.arena.river_rect.collidepoint(unit.pos.x, unit.pos.y):
                # Check if it's on a bridge
                on_left = self.arena.left_bridge_rect.collidepoint(unit.pos.x, unit.pos.y)
                on_right = self.arena.right_bridge_rect.collidepoint(unit.pos.x, unit.pos.y)
                
                if not on_left and not on_right:
                    print(f"FAIL: Unit entered river at {unit.pos} without being on a bridge!")
                    entered_river_illegally = True
                    break
            
            # Stop if passed the river
            if unit.pos.y < self.arena.river_rect.top:
                break
                
        if entered_river_illegally:
            self.fail("Unit walked into the river without using a bridge.")

if __name__ == '__main__':
    unittest.main()
