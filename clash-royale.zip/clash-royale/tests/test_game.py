import unittest
import pygame
from game import Game
from sprites import Unit, Tower
from settings import *

# Mock pygame setup
pygame.init()
pygame.display.set_mode((1, 1))

class TestGameLogic(unittest.TestCase):
    def setUp(self):
        self.screen = pygame.display.get_surface()
        self.game = Game(self.screen)

    def test_initial_state(self):
        self.assertEqual(self.game.elixir, 5)
        self.assertEqual(len(self.game.hand), 4)
        self.assertEqual(len(self.game.deck), 3) # 8 total - 4 hand - 1 next = 3 remaining
        self.assertIsNotNone(self.game.next_card)
        
    def test_elixir_regeneration(self):
        initial_elixir = self.game.elixir
        # Simulate time passing
        self.game.update(ELIXIR_REGEN_RATE + 0.1)
        self.assertEqual(self.game.elixir, initial_elixir + 1)
        
    def test_deck_cycling(self):
        initial_hand = self.game.hand.copy()
        card_to_play = initial_hand[0]
        next_card_before = self.game.next_card
        
        # Simulate playing a card (manually manipulating state as handle_event is hard to mock)
        self.game.hand.pop(0)
        self.game.hand.insert(0, self.game.next_card)
        self.game.deck.append(card_to_play)
        self.game.next_card = self.game.deck.pop(0)
        
        self.assertEqual(self.game.hand[0], next_card_before)
        self.assertIn(card_to_play, self.game.deck) # Should be at bottom (or somewhere in deck)
        
    def test_spawn_zones_initial(self):
        rects = self.game.get_valid_spawn_rects()
        self.assertEqual(len(rects), 1)
        self.assertEqual(rects[0].y, SCREEN_HEIGHT // 2) # Player side
        
    def test_spawn_zones_pocket(self):
        # Kill left enemy tower
        self.game.left_tower_e.health = 0
        self.game.left_tower_e.kill()
        
        rects = self.game.get_valid_spawn_rects()
        self.assertEqual(len(rects), 2) # Player side + Left pocket
        
        # Check if one rect starts at y=0
        has_pocket = False
        for r in rects:
            if r.y == 0:
                has_pocket = True
                break
        self.assertTrue(has_pocket)

if __name__ == '__main__':
    unittest.main()
