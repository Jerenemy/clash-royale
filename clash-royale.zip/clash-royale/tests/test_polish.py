import unittest
import pygame
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from assets import assets
from particles import particle_system

class TestPolish(unittest.TestCase):
    def setUp(self):
        pygame.init()
        # Dummy display for image loading
        pygame.display.set_mode((1, 1))

    def test_asset_manager(self):
        # Test safe loading of missing files
        sound = assets.load_sound("non_existent", "path/to/nothing.wav")
        self.assertIsNone(sound)
        
        # Test safe playing
        try:
            assets.play_sound("non_existent")
        except Exception as e:
            self.fail(f"play_sound raised exception: {e}")

    def test_particle_system(self):
        # Test adding particles
        particle_system.create_explosion(100, 100, (255, 0, 0))
        self.assertGreater(len(particle_system.particles), 0)
        
        # Test update
        initial_count = len(particle_system.particles)
        particle_system.update(0.1)
        # Particles should still be alive
        self.assertEqual(len(particle_system.particles), initial_count)
        
        # Test decay
        particle_system.update(10.0) # Long time
        self.assertEqual(len(particle_system.particles), 0)

if __name__ == '__main__':
    unittest.main()
