import unittest
import pygame
from unittest.mock import MagicMock
import math

# Initialize pygame for tests
pygame.init()
pygame.display.set_mode((1, 1))

from game.core.managers import BattleManager
from game.entities.sprites import Unit, Tower
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT

class TestTowerCollision(unittest.TestCase):
    def setUp(self):
        self.screen = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.mock_engine = MagicMock()
        self.mock_engine.virtual_surface = self.screen
        self.manager = BattleManager(self.mock_engine)
        
        # Clear existing units/towers if any (BattleManager creates towers in init/setup_arena)
        # But BattleManager calls setup_arena which creates towers.
        # Let's verify we have towers.
        self.assertTrue(len(self.manager.towers) > 0)

    def test_unit_avoids_tower(self):
        """Test that a unit moving towards a target behind a tower gets pushed aside."""
        
        # Find a tower (e.g., Player Princess Tower Left)
        # Player towers are at the bottom.
        # Let's pick the left princess tower.
        tower = None
        for t in self.manager.towers:
            if t.team == "player" and t.type == "princess" and t.pos.x < SCREEN_WIDTH / 2:
                tower = t
                break
        
        if not tower:
            self.skipTest("Could not find player left princess tower")
            
        # Place a unit slightly off-center below the tower
        start_x = tower.pos.x + 5
        start_y = tower.pos.y + tower.size + 20 
        
        unit = Unit(self.manager, start_x, start_y, "knight", "player")
        
        # Set a target directly ABOVE the tower
        # We can mock a target or just set a target position if we modify the unit to allow manual target pos
        # Or we can spawn an enemy unit above the tower.
        
        target_x = tower.pos.x
        target_y = tower.pos.y - 100
        
        # Create a dummy target
        target = MagicMock()
        target.rect = pygame.Rect(target_x, target_y, 10, 10)
        target.rect.center = (target_x, target_y)
        target.pos = pygame.math.Vector2(target_x, target_y)
        target.alive.return_value = True
        target.team = "enemy"
        # Mock unit_type for can_target check
        target.unit_type = "ground"
        
        unit.target = target
        
        # Update for several frames
        # The unit should try to move UP towards the target.
        # But it should hit the tower and be pushed sideways.
        
        initial_x = unit.pos.x
        
        for _ in range(120): # 2 seconds at 60 FPS
            unit.update(1/60.0)
            
        # Check if unit has deviated from X center
        # If collision works, it should have been pushed left or right.
        
        deviation = abs(unit.pos.x - initial_x)
        print(f"Unit X deviation: {deviation}")
        
        # It should have deviated significantly (e.g. > 5 pixels)
        self.assertGreater(deviation, 5.0, "Unit did not deviate from straight path through tower!")
        
        # Also check distance to tower center. It should be >= collision radius roughly.
        dist = unit.pos.distance_to(tower.pos)
        min_dist = (tower.size / 2) + 10
        # It might penetrate slightly due to soft physics, but shouldn't be deep inside.
        # Let's say at least 80% of min_dist (allowing some overlap before pushback kicks in)
        self.assertGreater(dist, min_dist * 0.8, f"Unit is inside the tower! Dist: {dist}, Min: {min_dist}")

if __name__ == '__main__':
    unittest.main()
