
import unittest
import pygame
from game.core.managers import BattleManager
from game.entities.sprites import Unit
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT

class MockEngine:
    def __init__(self):
        self.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.mouse_pos = (0, 0)
    
    def get_mouse_pos(self):
        return self.mouse_pos

class TestLatency(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MockEngine()
        self.manager1 = BattleManager(self.engine, practice_mode=False)
        self.manager2 = BattleManager(self.engine, practice_mode=False)
        
    def test_latency_divergence(self):
        # Simulate two clients
        # Client 1 executes action at t=0
        # Client 2 executes action at t=0.1 (100ms latency)
        
        # Fixed timestep
        dt = 1.0 / 60.0
        
        # Run for a bit to sync
        for _ in range(10):
            self.manager1.update(dt)
            self.manager2.update(dt)
            
        # Action: Spawn Knight
        spawn_pos = (100, 300)
        
        # Target tick: Current tick + buffer (e.g. 10)
        # Both managers should be at same tick (approx 10)
        target_tick = self.manager1.tick + 10
        print(f"Current Tick: {self.manager1.tick}, Target Tick: {target_tick}")
        
        # Track execution ticks
        self.execution_ticks = {"m1": None, "m2": None}
        
        # Monkey patch execute_play_card to capture tick
        original_execute_m1 = self.manager1.execute_play_card
        original_execute_m2 = self.manager2.execute_play_card
        
        def mock_execute_m1(*args, **kwargs):
            # If target_tick is None, it's being executed from queue
            if kwargs.get("target_tick") is None:
                self.execution_ticks["m1"] = self.manager1.tick
                print(f"M1 Executed at tick {self.manager1.tick}")
            original_execute_m1(*args, **kwargs)
            
        def mock_execute_m2(*args, **kwargs):
            if kwargs.get("target_tick") is None:
                self.execution_ticks["m2"] = self.manager2.tick
                print(f"M2 Executed at tick {self.manager2.tick}")
            original_execute_m2(*args, **kwargs)
            
        self.manager1.execute_play_card = mock_execute_m1
        self.manager2.execute_play_card = mock_execute_m2
        
        # Manager 1 executes immediately (simulating receiving own action or echo)
        self.manager1.execute_play_card("knight", spawn_pos, "player", ["id1"], target_tick=target_tick)
        
        # Manager 2 waits 6 frames (approx 100ms) then executes (simulating network latency)
        latency_frames = 6
        
        for i in range(20): # Shorten for debug
            if i == latency_frames:
                print(f"Spawning M2 at frame {i} (Tick {self.manager2.tick}) with target {target_tick}")
                self.manager2.execute_play_card("knight", spawn_pos, "player", ["id1"], target_tick=target_tick)
                
            self.manager1.update(dt)
            self.manager2.update(dt)
            
        # Verify execution ticks
        print(f"Execution Ticks: {self.execution_ticks}")
        self.assertEqual(self.execution_ticks["m1"], target_tick, "M1 executed at wrong tick")
        self.assertEqual(self.execution_ticks["m2"], target_tick, "M2 executed at wrong tick")
        self.assertEqual(self.execution_ticks["m1"], self.execution_ticks["m2"], "Managers executed at different ticks")

        # Check divergence
        # Get the knight from each
        k1 = list(self.manager1.units)[0]
        k2 = list(self.manager2.units)[0]
        
        print(f"K1 Pos: {k1.pos}")
        print(f"K2 Pos: {k2.pos}")
        
        dist_diff = k1.pos.distance_to(k2.pos)
        print(f"Divergence: {dist_diff}")
        
        # If dist_diff > epsilon, then latency causes divergence
        self.assertLess(dist_diff, 1.0, "Latency caused significant divergence")

if __name__ == '__main__':
    unittest.main()
