# Tests Directory

This directory contains unit tests and integration tests for the Clash Royale clone. The tests are written using `pytest`.

## Running Tests

To run all tests, execute the following command from the root directory:

```bash
pytest
```

To run a specific test file:

```bash
pytest tests/test_game_logic.py
```

## Test Files

-   **`test_game_logic.py`**: Tests core game mechanics like elixir generation, card cycling, and win conditions.
-   **`test_gameplay.py`**: Tests specific gameplay scenarios, such as unit interactions and tower damage.
-   **`test_network_protocol.py`**: Tests the encoding and decoding of network messages.
-   **`test_multiplayer_sync.py`**: Tests synchronization between client and server states.
-   **`test_determinism.py`**: Ensures that the game simulation is deterministic given the same inputs.
-   **`test_symmetry.py`**: Verifies that the game is fair and symmetrical for both players.
-   **`test_card_play.py`**: Tests the logic for playing cards, including cost checks and placement validation.
-   **`test_bounds.py`**: Checks that units stay within the arena boundaries.
