import unittest
import pygame
from unittest.mock import MagicMock
from game.core.managers import BattleManager
from game.core.registry import CardRegistry
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT
from game.network.controller import NetworkController

class TestServerEcho(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MagicMock()
        self.engine.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.game = BattleManager(self.engine)
        CardRegistry.initialize()
        
        # Mock player hand
        self.game.player.hand = [CardRegistry.get("knight")] * 4
        self.game.player.elixir = 10
        self.game.dragging_card_idx = 0
        
        # Mock network controller
        self.client = MagicMock()
        self.controller = NetworkController(self.game, self.client, "player")
        
    def tearDown(self):
        pygame.quit()

    def test_try_play_card_sends_only(self):
        """Test that try_play_card sends message but does not spawn locally."""
        initial_units = len(self.game.units)
        
        # Mock the callback
        self.game.on_card_played = MagicMock()
        
        # Mock valid spawn rects to include (100, 100)
        self.game.get_valid_spawn_rects = MagicMock(return_value=[pygame.Rect(0, 0, 500, 500)])
        
        # Try play card
        self.game.try_play_card((100, 100))
        
        # Should call callback
        self.game.on_card_played.assert_called_once()
        
        # Should NOT spawn unit yet
        self.assertEqual(len(self.game.units), initial_units)
        
    def test_execute_play_card_spawns(self):
        """Test that execute_play_card actually spawns the unit."""
        initial_units = len(self.game.units)
        
        self.game.execute_play_card("knight", (100, 100), "player")
        
        # Should spawn unit
        self.assertEqual(len(self.game.units), initial_units + 1)
        unit = self.game.units.sprites()[-1]
        self.assertEqual(unit.unit_type_name, "knight")
        self.assertEqual(unit.team, "player")

    def test_network_echo_handling(self):
        """Test that NetworkController handles echoed message correctly."""
        # Simulate receiving "play_card" from "player" (Self Echo)
        data = {
            "card_name": "knight",
            "pos_x": 100,
            "pos_y": 100,
            "side": "player", # Same as self.server_side
            "network_ids": ["test_id"]
        }
        
        self.controller._handle_remote_play_card(data)
        
        # Should spawn unit as "player" at (100, 100)
        unit = self.game.units.sprites()[-1]
        self.assertEqual(unit.unit_type_name, "knight")
        self.assertEqual(unit.team, "player")
        self.assertEqual(unit.pos.x, 100)
        
    def test_network_enemy_handling(self):
        """Test that NetworkController handles enemy message correctly."""
        # Simulate receiving "play_card" from "enemy"
        data = {
            "card_name": "knight",
            "pos_x": 100,
            "pos_y": 100,
            "side": "enemy", # Different from self.server_side
            "network_ids": ["test_id"]
        }
        
        self.controller._handle_remote_play_card(data)
        
        # Should spawn unit as "enemy" at FLIPPED coordinates
        # x = SCREEN_WIDTH - 100 = 540 - 100 = 440
        # y = playable_height - 100 = 780 - 100 = 680
        
        unit = self.game.units.sprites()[-1]
        self.assertEqual(unit.unit_type_name, "knight")
        self.assertEqual(unit.team, "enemy")
        self.assertEqual(unit.pos.x, SCREEN_WIDTH - 100)

if __name__ == '__main__':
    unittest.main()
