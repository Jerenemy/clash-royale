import unittest
from game.models import Player
from game.settings import UNIT_STATS, SPELL_STATS

class TestCardPlay(unittest.TestCase):
    def setUp(self):
        # Create a deck of 8 cards
        self.deck_names = ["knight", "archer", "giant", "arrows", "fireball", "minions", "musketeer", "baby_dragon"]
        self.player = Player("player", self.deck_names)
        # Give infinite elixir for testing mechanics
        self.player.elixir = 10

    def test_initial_state(self):
        """Test that player starts with 4 cards in hand and 1 next card."""
        self.assertEqual(len(self.player.hand), 4)
        self.assertIsNotNone(self.player.next_card)
        self.assertEqual(len(self.player.deck), 3) # 8 - 4 - 1 = 3
        # Verify they are Card objects
        self.assertTrue(hasattr(self.player.hand[0], "name"))

    def test_play_card_cycle(self):
        """Test playing cards cycles the deck correctly."""
        initial_hand = self.player.hand.copy()
        card_to_play = initial_hand[0]
        next_card_expected = self.player.next_card
        
        # Play the first card
        played_card = self.player.play_card(0)
        
        self.assertEqual(played_card, card_to_play)
        self.assertEqual(len(self.player.hand), 4) # Should still be 4
        self.assertEqual(self.player.hand[0], next_card_expected) # Next card should take slot
        self.assertNotEqual(self.player.next_card, next_card_expected) # Should have new next card
        self.assertIn(card_to_play, self.player.deck) # Played card should be back in deck/cycle

    def test_play_multiple_cards(self):
        """Test playing multiple cards in succession."""
        for i in range(10):
            card = self.player.hand[0]
            self.player.play_card(0)
            self.assertEqual(len(self.player.hand), 4, f"Hand size wrong after play {i+1}")
            self.assertIsNotNone(self.player.next_card, f"Next card missing after play {i+1}")

    def test_elixir_spending(self):
        """Test that playing a card spends elixir."""
        card = self.player.hand[0]
        cost = card.cost
        
        start_elixir = self.player.elixir
        self.player.spend_elixir(cost)
        
        self.assertEqual(self.player.elixir, start_elixir - cost)

if __name__ == '__main__':
    unittest.main()
