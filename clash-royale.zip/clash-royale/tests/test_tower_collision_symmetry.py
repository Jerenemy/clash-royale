import unittest
import pygame
from unittest.mock import MagicMock
import math

# Initialize pygame for tests
pygame.init()
pygame.display.set_mode((1, 1))

from game.core.managers import BattleManager
from game.entities.sprites import Unit, Tower
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT
from game.core.symmetry import SymmetryUtils

class TestTowerCollisionSymmetry(unittest.TestCase):
    def setUp(self):
        self.screen = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.mock_engine = MagicMock()
        self.mock_engine.virtual_surface = self.screen
        self.manager = BattleManager(self.mock_engine)
        self.manager.playable_height = 620 # Standard playable height
        
        # Ensure arena is set up
        # BattleManager sets up arena in init usually, but let's make sure we have the towers we expect
        # Player Left Tower: (80, H-124)
        # Enemy Right Tower: (W-80, 124)
        
        self.tower_p = self.manager.left_tower_p
        self.tower_e = self.manager.right_tower_e
        
        # Verify tower positions are mirrored
        self.assertAlmostEqual(self.tower_p.pos.x, SymmetryUtils.flip_x(self.tower_e.pos.x))
        self.assertAlmostEqual(self.tower_p.pos.y, SymmetryUtils.flip_y(self.tower_e.pos.y))

    def test_tower_collision_symmetry(self):
        """Test that units colliding with towers behave symmetrically."""
        
        # Setup Player Unit
        # Place slightly off-center below the tower
        start_x_p = self.tower_p.pos.x + 5
        start_y_p = self.tower_p.pos.y + self.tower_p.size + 20
        
        unit_p = Unit(self.manager, start_x_p, start_y_p, "knight", "player", network_id="unit_p")
        
        # Setup Enemy Unit (Mirrored)
        start_x_e = SymmetryUtils.flip_x(start_x_p)
        start_y_e = SymmetryUtils.flip_y(start_y_p)
        
        unit_e = Unit(self.manager, start_x_e, start_y_e, "knight", "enemy", network_id="unit_e")
        
        # Verify start positions are mirrored
        self.assertAlmostEqual(unit_p.pos.x, SymmetryUtils.flip_x(unit_e.pos.x))
        self.assertAlmostEqual(unit_p.pos.y, SymmetryUtils.flip_y(unit_e.pos.y))
        
        # Setup Targets
        # Target for Player: Above the tower
        target_x_p = self.tower_p.pos.x
        target_y_p = self.tower_p.pos.y - 100
        
        target_p = MagicMock()
        target_p.rect = pygame.Rect(target_x_p, target_y_p, 10, 10)
        target_p.rect.center = (target_x_p, target_y_p)
        target_p.pos = pygame.math.Vector2(target_x_p, target_y_p)
        target_p.alive.return_value = True
        target_p.unit_type = "ground"
        target_p.team = "enemy"
        target_p.get_closest_point = MagicMock(side_effect=lambda p: pygame.math.Vector2(target_p.rect.center))
        
        unit_p.target = target_p
        
        # Target for Enemy: Mirrored (Below the tower)
        target_x_e = SymmetryUtils.flip_x(target_x_p)
        target_y_e = SymmetryUtils.flip_y(target_y_p)
        
        target_e = MagicMock()
        target_e.rect = pygame.Rect(target_x_e, target_y_e, 10, 10)
        target_e.rect.center = (target_x_e, target_y_e)
        target_e.pos = pygame.math.Vector2(target_x_e, target_y_e)
        target_e.alive.return_value = True
        target_e.unit_type = "ground"
        target_e.team = "player"
        target_e.get_closest_point = MagicMock(side_effect=lambda p: pygame.math.Vector2(target_e.rect.center))
        
        unit_e.target = target_e
        
        # Step Simulation
        for i in range(120): # 2 seconds
            unit_p.think(1/60.0)
            unit_e.think(1/60.0)
            unit_p.update(1/60.0)
            unit_e.update(1/60.0)
            
            # Verify Symmetry at each step
            # Allow small floating point error
            self.assertAlmostEqual(unit_p.pos.x, SymmetryUtils.flip_x(unit_e.pos.x), places=4, msg=f"X Asymmetry at frame {i}")
            self.assertAlmostEqual(unit_p.pos.y, SymmetryUtils.flip_y(unit_e.pos.y), places=4, msg=f"Y Asymmetry at frame {i}")
            
        # Check that they actually moved and collided (deviated from straight line)
        deviation_p = abs(unit_p.pos.x - start_x_p)
        self.assertGreater(deviation_p, 5.0, "Player unit did not deviate (no collision?)")
        
        deviation_e = abs(unit_e.pos.x - start_x_e)
        self.assertGreater(deviation_e, 5.0, "Enemy unit did not deviate (no collision?)")

if __name__ == '__main__':
    unittest.main()
