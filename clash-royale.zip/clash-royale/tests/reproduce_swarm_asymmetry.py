import unittest
import pygame
from game.core.managers import BattleManager
from game.core.symmetry import SymmetryUtils
from game.entities.sprites import Unit
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT, GRID_MARGIN_Y, GRID_HEIGHT, TILE_SIZE

class TestSwarmAsymmetry(unittest.TestCase):
    def setUp(self):
        pygame.init()
        # Mock engine
        self.engine = type('Engine', (), {'virtual_surface': pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT)), 'get_mouse_pos': lambda: (0,0)})()
        self.manager = BattleManager(self.engine)
        
        # Disable random seed for determinism if any remains
        import random
        random.seed(42)

    def test_skarmy_vs_goblin_gang_symmetry(self):
        """
        Simulate a mirrored battle:
        - Player plays Skeleton Army at left bridge.
        - Enemy plays Skeleton Army (mirrored) at right bridge.
        - AND
        - Player plays Goblin Gang at right bridge.
        - Enemy plays Goblin Gang (mirrored) at left bridge.
        
        Wait, the user said: "played a skeleton army which crossed the bridge, then i played a goblin gang as the defender".
        This implies an interaction between Skarmy and Goblin Gang.
        
        Let's try a simpler symmetric setup first to see if P vs E is symmetric.
        Scenario:
        - Player spawns Skeleton Army at Left Bridge.
        - Enemy spawns Skeleton Army at Right Bridge (Mirrored).
        
        If this passes, we try:
        - Player spawns Skarmy vs Enemy Goblin Gang (Left Lane)
        - Enemy spawns Skarmy vs Player Goblin Gang (Right Lane)
        And compare the results of the two lanes.
        """
        
        # Lane positions
        left_lane_x = 100 # Approx
        right_lane_x = SCREEN_WIDTH - 100
        
        bridge_y = GRID_MARGIN_Y + (GRID_HEIGHT * TILE_SIZE) / 2.0
        
        # Scenario: Symmetric Battle in two lanes
        # Lane 1 (Left): Player Skarmy vs Enemy Goblin Gang
        # Lane 2 (Right): Enemy Skarmy vs Player Goblin Gang (Mirrored)
        
        # Spawn positions relative to bridge
        p_spawn_y = bridge_y + 50
        e_spawn_y = bridge_y - 50
        
        # Lane 1 (Left)
        # Player Skarmy
        p_skarmy_pos = (left_lane_x, p_spawn_y)
        self.manager.spawn_card("skeleton_army", p_skarmy_pos, "player", network_ids=[f"p_skarmy_{i}" for i in range(15)])
        
        # Enemy Goblin Gang
        e_goblin_pos = (left_lane_x, e_spawn_y)
        self.manager.spawn_card("goblin_gang", e_goblin_pos, "enemy", network_ids=[f"e_goblin_{i}" for i in range(6)])
        
        # Lane 2 (Right) - Mirrored
        # Enemy Skarmy (Mirrored P Skarmy)
        e_skarmy_pos = SymmetryUtils.flip_pos(p_skarmy_pos)
        self.manager.spawn_card("skeleton_army", e_skarmy_pos, "enemy", network_ids=[f"e_skarmy_{i}" for i in range(15)])
        
        # Player Goblin Gang (Mirrored E Goblin Gang)
        p_goblin_pos = SymmetryUtils.flip_pos(e_goblin_pos)
        self.manager.spawn_card("goblin_gang", p_goblin_pos, "player", network_ids=[f"p_goblin_{i}" for i in range(6)])
        
        # Run simulation
        for frame in range(300): # 5 seconds
            # print(f"--- Frame {frame} ---") # Uncomment for detailed debug
            self.manager.update(0.016)
            
            # Check symmetry of surviving units count
            p_skarmy_count = sum(1 for u in self.manager.units if u.team == "player" and "skeleton" in u.unit_type_name and u.alive())
            e_skarmy_count = sum(1 for u in self.manager.units if u.team == "enemy" and "skeleton" in u.unit_type_name and u.alive())
            
            p_goblin_count = sum(1 for u in self.manager.units if u.team == "player" and "goblin" in u.unit_type_name and u.alive())
            e_goblin_count = sum(1 for u in self.manager.units if u.team == "enemy" and "goblin" in u.unit_type_name and u.alive())
            
            # Assert counts are equal
            if p_skarmy_count != e_skarmy_count:
                print(f"Frame {frame} Skarmy Asymmetry: P={p_skarmy_count} E={e_skarmy_count}")
                # Fail immediately to debug
                self.assertEqual(p_skarmy_count, e_skarmy_count, f"Skarmy count mismatch at frame {frame}")
                
            if p_goblin_count != e_goblin_count:
                print(f"Frame {frame} Goblin Asymmetry: P={p_goblin_count} E={e_goblin_count}")
                self.assertEqual(p_goblin_count, e_goblin_count, f"Goblin count mismatch at frame {frame}")

if __name__ == "__main__":
    unittest.main()
