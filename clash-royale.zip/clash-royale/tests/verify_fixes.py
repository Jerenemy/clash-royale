import unittest
import pygame
import sys
import os

# Add game directory to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from game.core.managers import BattleManager
from game.settings import *

class MockEngine:
    def __init__(self):
        self.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.mouse_pos = (0, 0)
        
    def get_mouse_pos(self):
        return self.mouse_pos

class TestGameLogic(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MockEngine()
        self.manager = BattleManager(self.engine)
        
    def test_snap_to_grid(self):
        # Test snapping logic
        # Grid starts at GRID_MARGIN_Y (20)
        # Tile size is 26
        
        # Test top-left tile (0, 0)
        # Input: slightly inside the tile
        input_pos = (GRID_MARGIN_X + 5, GRID_MARGIN_Y + 5)
        expected_center = (GRID_MARGIN_X + TILE_SIZE // 2, GRID_MARGIN_Y + TILE_SIZE // 2)
        snapped = self.manager.snap_to_grid(input_pos)
        self.assertEqual(snapped, expected_center, f"Failed to snap to top-left tile. Got {snapped}, expected {expected_center}")
        
        # Test a tile in the middle
        # Row 10, Col 5
        input_pos = (GRID_MARGIN_X + 5 * TILE_SIZE + 10, GRID_MARGIN_Y + 10 * TILE_SIZE + 10)
        expected_center = (GRID_MARGIN_X + 5 * TILE_SIZE + TILE_SIZE // 2, GRID_MARGIN_Y + 10 * TILE_SIZE + TILE_SIZE // 2)
        snapped = self.manager.snap_to_grid(input_pos)
        self.assertEqual(snapped, expected_center, f"Failed to snap to middle tile. Got {snapped}, expected {expected_center}")
        
    def test_king_tower_position(self):
        # Check King Tower positions
        # Enemy (Top): Row 1
        expected_y_e = GRID_MARGIN_Y + 1 * TILE_SIZE + TILE_SIZE // 2
        self.assertEqual(self.manager.king_tower_e.pos.y, expected_y_e, "Enemy King Tower position incorrect")
        
        # Player (Bottom): Row 20 (GRID_HEIGHT - 2)
        expected_y_p = GRID_MARGIN_Y + (GRID_HEIGHT - 2) * TILE_SIZE + TILE_SIZE // 2
        self.assertEqual(self.manager.king_tower_p.pos.y, expected_y_p, "Player King Tower position incorrect")
        
    def test_unit_placement_restriction(self):
        # Try to place a unit on top of the player's King Tower
        king_pos = self.manager.king_tower_p.pos
        
        # Select a card (Knight)
        self.manager.selected_card_idx = 0
        self.manager.player.hand[0] = self.manager.player.deck[0] # Ensure card exists
        self.manager.player.elixir = 10 # Infinite elixir
        
        # Mock mouse pos to be exactly on King Tower
        # snap_to_grid will snap it to the tile center, which should match King Tower pos
        # But we need to pass screen coordinates to try_play_card
        screen_pos = (king_pos.x, king_pos.y)
        
        # Try to play
        success = self.manager.try_play_card(screen_pos)
        self.assertFalse(success, "Should not be able to place unit on top of King Tower")
        
        # Try to place NEXT to the tower (valid)
        # Move 2 tiles away
        valid_pos = (king_pos.x + 2 * TILE_SIZE, king_pos.y)
        success = self.manager.try_play_card(valid_pos)
        # This might fail if it's outside valid spawn rects, so let's check spawn rects first
        # King tower is at bottom, so 2 tiles right should be valid spawn area?
        # Let's check if it's in valid rects
        snapped_valid = self.manager.snap_to_grid(valid_pos)
        valid_rects = self.manager.get_valid_spawn_rects()
        is_valid_area = any(r.collidepoint(snapped_valid) for r in valid_rects)
        
        if is_valid_area:
             self.assertTrue(success, "Should be able to place unit next to tower")
        else:
             print("Skipping valid placement test as position is outside spawn area")

if __name__ == '__main__':
    unittest.main()
