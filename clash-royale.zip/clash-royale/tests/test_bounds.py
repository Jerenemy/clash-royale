import unittest
import pygame
from game.core.managers import BattleManager
from game.core.engine import GameEngine
from game.settings import *

class TestBounds(unittest.TestCase):
    def setUp(self):
        pygame.init()
        # Initialize display for font rendering
        pygame.display.set_mode((1, 1), pygame.NOFRAME)
        pygame.font.init()
        
        self.engine = GameEngine()
        self.manager = BattleManager(self.engine)

    def test_tower_positions_within_bounds(self):
        """Check if all towers are within the playable area."""
        for tower in self.manager.towers:
            self.assertTrue(tower.rect.left >= 0, f"{tower.type} left {tower.rect.left} < 0")
            self.assertTrue(tower.rect.right <= SCREEN_WIDTH, f"{tower.type} right {tower.rect.right} > {SCREEN_WIDTH}")
            self.assertTrue(tower.rect.top >= 0, f"{tower.type} top {tower.rect.top} < 0")
            self.assertTrue(tower.rect.bottom <= self.manager.playable_height, f"{tower.type} bottom {tower.rect.bottom} > {self.manager.playable_height}")

    def test_hp_text_within_bounds(self):
        """Check if HP text for towers is drawn within screen bounds."""
        font_small = pygame.font.SysFont("Arial", 16, bold=True)
        
        for tower in self.manager.towers:
            # Logic from BattleManager.draw
            if tower.type == "king" and not tower.active:
                continue

            hp_text = font_small.render(f"{int(tower.health)}", True, WHITE)
            
            if tower.team == "enemy":
                if tower.type == "princess":
                    text_y = tower.rect.bottom + 2
                else:
                    text_y = max(0, tower.rect.top - 15)
            else:
                text_y = tower.rect.top - 12
                
            text_x = tower.rect.centerx - hp_text.get_width() // 2
            
            text_rect = pygame.Rect(text_x, text_y, hp_text.get_width(), hp_text.get_height())
            
            print(f"Checking {tower.team} {tower.type} HP text at {text_rect}")
            
            self.assertTrue(text_rect.top >= 0, f"{tower.team} {tower.type} HP text top {text_rect.top} < 0")
            self.assertTrue(text_rect.left >= 0, f"{tower.team} {tower.type} HP text left {text_rect.left} < 0")
            self.assertTrue(text_rect.right <= SCREEN_WIDTH, f"{tower.team} {tower.type} HP text right {text_rect.right} > {SCREEN_WIDTH}")
            # Bottom check isn't as critical for top items, but let's check anyway
            self.assertTrue(text_rect.bottom <= self.manager.playable_height, f"{tower.team} {tower.type} HP text bottom {text_rect.bottom} > {self.manager.playable_height}")

    def tearDown(self):
        pygame.quit()

if __name__ == "__main__":
    unittest.main()
