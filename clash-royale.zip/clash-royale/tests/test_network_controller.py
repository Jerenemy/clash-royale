import unittest
from unittest.mock import MagicMock
from game.network.controller import NetworkController
from game.network.protocol import ActionType
from game.core.card import UnitCard

class TestNetworkController(unittest.TestCase):
    def setUp(self):
        self.mock_game = MagicMock()
        self.mock_client = MagicMock()
        self.controller = NetworkController(self.mock_game, self.mock_client, "player")

    def test_handle_local_card_play(self):
        """Test that local card play sends action to client."""
        card = UnitCard("knight", {"cost": 3, "unit_type": "ground"})
        pos = (100, 200)
        network_ids = ["id1"]
        
        self.controller.handle_local_card_play(card, pos, network_ids)
        
        self.mock_client.send_action.assert_called_once()
        args = self.mock_client.send_action.call_args[0]
        self.assertEqual(args[0], ActionType.PLAY_CARD.value)
        self.assertEqual(args[1]["card_name"], "knight")
        self.assertEqual(args[1]["pos_x"], 100)
        self.assertEqual(args[1]["pos_y"], 200)

    def test_handle_remote_play_card(self):
        """Test that remote card play calls spawn_card on game."""
        data = {
            "card_name": "archer",
            "pos_x": 100,
            "pos_y": 200,
            "side": "enemy",
            "network_ids": ["id2"]
        }
        
        self.controller.handle_remote_action(ActionType.PLAY_CARD.value, data)
        
        self.mock_game.spawn_card.assert_called_once()
        args = self.mock_game.spawn_card.call_args[0]
        self.assertEqual(args[0], "archer")
        # Check coordinate flipping (assuming SCREEN_WIDTH=540, SCREEN_HEIGHT=960 from settings)
        # But we can't easily import settings here if we want to be pure unit test.
        # The controller imports settings.
        # Let's just check that it was called.
        self.assertEqual(args[2], "enemy")
        self.assertEqual(args[3], ["id2"])

if __name__ == '__main__':
    unittest.main()
