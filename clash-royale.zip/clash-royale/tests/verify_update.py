import sys
import os
import pygame

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from game.entities.sprites import Tower

def verify_update():
    pygame.init()
    
    # Mock game object
    class MockGame:
        def __init__(self):
            self.all_sprites = pygame.sprite.Group()
            self.towers = pygame.sprite.Group()
            self.units = pygame.sprite.Group()
            self.projectiles = pygame.sprite.Group()
            self.playable_height = 600
            
    mock_game = MockGame()
    
    print("Creating Tower...")
    tower = Tower(mock_game, 100, 100, "princess", "player")
    
    print("Calling tower.update(0.1)...")
    try:
        tower.update(0.1)
        print("PASS: tower.update() ran without error.")
    except AttributeError as e:
        print(f"FAIL: AttributeError: {e}")
    except Exception as e:
        print(f"FAIL: Exception: {e}")

if __name__ == "__main__":
    verify_update()
    pygame.quit()
