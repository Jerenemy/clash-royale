import unittest
import pygame
import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from game.settings import *
from game.core.managers import BattleManager
from game.entities.sprites import Unit

class MockEngine:
    def __init__(self):
        self.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    def get_mouse_pos(self):
        return (0, 0)

class TestTargetingBehavior(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MockEngine()
        self.manager = BattleManager(self.engine)

    def test_switch_target_before_attack(self):
        # Scenario: Unit A targets B (far). C (close) appears. A should switch to C if it hasn't attacked B yet.
        
        # Unit A (Player) at (100, 600)
        unit_a = Unit(self.manager, 100, 600, "knight", "player")
        
        # Unit B (Enemy) at (100, 800) -> Dist 200
        unit_b = Unit(self.manager, 100, 800, "knight", "enemy")
        
        # Ensure A targets B
        unit_a.update(0.1)
        self.assertEqual(unit_a.target, unit_b, f"Unit A should target B initially. Got {unit_a.target}")
        
        # Unit C (Enemy) appears at (100, 650) -> Dist 50
        unit_c = Unit(self.manager, 100, 650, "knight", "enemy")
        
        # Update A. It has NOT attacked B yet. It should switch to C.
        # Force retarget check
        unit_a.retarget_timer = 0
        unit_a.update(0.1)
        
        if unit_a.target == unit_b:
            self.fail("Unit A stayed locked on B even though C is closer and A hasn't attacked yet.")
            
        self.assertEqual(unit_a.target, unit_c, "Unit A should switch to C because it hasn't locked onto B yet")
        
    def test_lock_target_after_attack(self):
        # Scenario: Unit A attacks B. Then C appears. A should STAY on B.
        
        # Unit A (Player) at (100, 600)
        unit_a = Unit(self.manager, 100, 600, "knight", "player")
        
        # Unit B (Enemy) at (100, 610) -> Dist 10 (Within range)
        unit_b = Unit(self.manager, 100, 610, "knight", "enemy")
        
        # Update to find target
        unit_a.update(0.1)
        self.assertEqual(unit_a.target, unit_b)
        
        # Force an attack
        # We need to simulate enough time passing or force the attack logic
        # Unit.update checks: if dist <= range and cooldown ready -> attack
        # Cooldown is initially 0 (ready)
        
        # Let's run update with a small dt, it should attack.
        # We force the attack timer to be ready
        unit_a.last_attack_time = unit_a.attack_cooldown
        unit_a.update(0.1)
        
        # Check if it attacked (last_attack_time should be reset to 0 or similar logic? 
        # Actually last_attack_time counts UP. When it attacks, it resets to 0?
        # Let's check the code logic for attack.
        # "if self.last_attack_time >= self.attack_cooldown:"
        # "self.last_attack_time = 0"
        
        # So if it attacked, last_attack_time should be small (0 + dt maybe?)
        
        # Unit C (Enemy) appears at (100, 605) -> Dist 5 (Closer than B)
        unit_c = Unit(self.manager, 100, 605, "knight", "enemy")
        
        # Update A
        unit_a.update(0.1)
        
        # Should STAY on B because it just attacked B (locked)
        self.assertEqual(unit_a.target, unit_b, "Unit A should stay locked on B after attacking it")

if __name__ == '__main__':
    unittest.main()
