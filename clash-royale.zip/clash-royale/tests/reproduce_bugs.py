import sys
import os
import pygame
import time

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from game.core.managers import BattleManager
from game.settings import *

def reproduce_bugs():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    
    # Initialize BattleManager
    # BattleManager(game_engine) where game_engine has .virtual_surface
    class MockEngine:
        def __init__(self, screen):
            self.virtual_surface = screen
            self.network_client = None
            
    engine = MockEngine(screen)
    manager = BattleManager(engine)
    manager.reset_game()
    
    print("--- Reproducing Bugs ---")
    
    # 1. Check Health Bar Visibility at Start
    print("\nChecking Health Bar Visibility...")
    # Princess Tower should have health bar drawn even at full health
    # We can't easily check pixels without rendering, but we can check the logic in code or just run the game.
    # For this script, let's simulate the draw call and see if it returns early.
    
    tower = manager.left_tower_p
    print(f"Tower Health: {tower.health}/{tower.max_health}")
    
    # Mock surface to draw on
    surf = pygame.Surface((100, 100))
    
    # We can't easily intercept the draw call return, but we know the code has:
    # if self.health >= self.max_health: return
    # So we will fix that.
    
    # 2. Check Skeleton Army Attack
    print("\nChecking Skeleton Army Attack...")
    # Spawn a Skeleton near the enemy tower
    # Skeleton range is usually very short (melee)
    # Tower size is now large (3.5 tiles = ~90px for King, 2.8 tiles = ~72px for Princess)
    # Collision radius = (TowerSize/2 + UnitSize/2)
    # Attack range needs to be >= Collision radius?
    # Actually, range check is usually: dist <= self.range + target.size/2?
    # Let's check how attack range is calculated in Unit.update:
    # if dist <= self.range + 0.001:
    # Wait, dist is center-to-center distance.
    # So if collision keeps them at (Size1/2 + Size2/2), then range must be >= (Size1/2 + Size2/2).
    
    # Let's verify the values.
    skeleton_stats = UNIT_STATS["skeleton_army"]
    tower_stats = TOWER_STATS["princess"]
    
    skel_size = skeleton_stats.get("size", 20)
    tower_size = tower_stats["size"]
    skel_range = skeleton_stats["range"]
    
    # Instantiate entities to test get_edge_distance
    from game.entities.sprites import Unit, Tower
    
    # Mock game object
    class MockGame:
        def __init__(self):
            self.all_sprites = pygame.sprite.Group()
            self.towers = pygame.sprite.Group()
            self.units = pygame.sprite.Group()
            self.projectiles = pygame.sprite.Group()
            self.playable_height = 600
            
    mock_game = MockGame()
    
    # Create Tower
    tower = Tower(mock_game, 100, 100, "princess", "enemy")
    
    # Create Skeleton (Unit)
    # Position it such that it is colliding with the tower edge
    # Tower Rect: Center(100,100), Size(72x72) -> Left=64, Right=136, Top=64, Bottom=136
    # Skeleton Size: 15 (Radius 7.5)
    # Place skeleton at (Hitbox Right + Radius, 100) -> Touching right edge of hitbox
    
    skel_x = tower.hitbox_rect.right + 7.5
    skel_y = 100
    skeleton = Unit(mock_game, skel_x, skel_y, "skeleton_army", "player")
    
    print(f"Tower Hitbox: {tower.hitbox_type}")
    print(f"Skeleton Hitbox: {skeleton.hitbox_type}")
    
    # Check Edge Distance
    edge_dist = skeleton.get_edge_distance(tower)
    print(f"Edge Distance: {edge_dist}")
    
    # Check Range
    skel_range = skeleton.range
    print(f"Skeleton Range: {skel_range}")
    
    # With new settings, range should be 5.
    # Edge distance is 0.
    
    if edge_dist <= skel_range + 0.001:
        print("PASS: Skeleton is in range (Edge-to-Edge).")
    else:
        print("FAIL: Skeleton is out of range!")
        print(f"Excess distance: {edge_dist - skel_range}")

if __name__ == "__main__":
    reproduce_bugs()
    pygame.quit()
