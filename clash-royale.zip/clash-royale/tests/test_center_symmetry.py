import unittest
import pygame
from unittest.mock import MagicMock
from game.core.managers import BattleManager
from game.entities.sprites import Unit
from game.settings import SCREEN_WIDTH, SCREEN_HEIGHT, HUD_HEIGHT

class TestCenterSymmetry(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.engine = MagicMock()
        self.engine.virtual_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.host_game = BattleManager(self.engine)
        self.client_game = BattleManager(self.engine)
        self.playable_height = SCREEN_HEIGHT - HUD_HEIGHT
        
    def tearDown(self):
        pygame.quit()
        
    def get_mirrored_pos(self, x, y):
        return SCREEN_WIDTH - x, self.playable_height - y

    def test_center_bridge_selection(self):
        """Test that a unit in the exact center picks symmetric bridges."""
        # Spawn unit at center X, bottom Y (Host Player)
        center_x = SCREEN_WIDTH // 2 # 270
        y = 600
        
        h_unit = Unit(self.host_game, center_x, y, "knight", "player")
        
        # Spawn mirrored unit (Client Enemy)
        mx, my = self.get_mirrored_pos(center_x, y)
        # mx should be 270
        self.assertEqual(mx, center_x)
        
        c_unit = Unit(self.client_game, mx, my, "knight", "enemy")
        
        # Force target to be across the river
        # Host target: Top Center (Enemy King)
        h_unit.target = self.host_game.king_tower_e
        
        # Client target: Bottom Center (Player King)
        c_unit.target = self.client_game.king_tower_p
        
        # Update to trigger pathfinding
        dt = 0.016
        h_unit.move_towards_target(dt)
        c_unit.move_towards_target(dt)
        
        # Check direction
        # If Host goes Right (positive x), Client should go Left (negative x)
        # Because Client's Left is the mirror of Host's Right.
        
        h_dx = h_unit.pos.x - center_x
        c_dx = c_unit.pos.x - mx
        
        print(f"Host dx: {h_dx}, Client dx: {c_dx}")
        
        # They should be opposite signs (or both 0 if they go straight, but bridge is side)
        # Actually, if they go to bridge, they have lateral movement.
        
        # If h_dx is positive (Right), c_dx should be negative (Left).
        if abs(h_dx) > 0.001:
            self.assertTrue(c_dx * h_dx < 0, "Units moved in the same lateral direction (asymmetric!)")

if __name__ == '__main__':
    unittest.main()
